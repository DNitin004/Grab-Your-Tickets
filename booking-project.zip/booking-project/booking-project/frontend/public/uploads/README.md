# Public Uploads Folder

This folder serves as the location for user-uploaded or static images that should be served directly by the dev server / production static host.

Location: `public/uploads/images`

How to use:
- Place image files into `public/uploads/images` (e.g. `avatar.jpg`).
- When running the dev server, files in `public/` are served at the web root.
  Example: `public/uploads/images/avatar.jpg` -> available at `/uploads/images/avatar.jpg`.

Notes:
- In production, ensure your build/publishing pipeline copies `public/uploads` to the server's static file location or configure your backend to serve uploaded files from a writable location (e.g. backend/static/images).
- If you plan to accept user uploads via a form, those files should be saved on the backend (e.g. `backend/static/images`) and not committed to this repo. The `public/uploads/images` folder is suitable for sample images or assets you want bundled/served by Vite during development.

Example in React component:

<img src="/uploads/images/example.jpg" alt="Example" />
