import React, { useState, useEffect } from "react";
import {
  Routes,
  Route,
  Link,
  useNavigate,
  useLocation,
} from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Ticket,
  User,
  LogOut,
  Menu,
  X,
  Settings,
  Film,
  Music,
  Plane,
  Train,
  Bus,
  Car,
} from "lucide-react";
import toast from "react-hot-toast";

// ✅ Import all pages
import Home from "./pages/Home.jsx";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";

import MovieBooking from "./pages/MovieBooking.jsx";
import ConcertBooking from "./pages/ConcertBooking.jsx";
import FlightBooking from "./pages/FlightBooking.jsx";
import TrainBooking from "./pages/TrainBooking.jsx"; // ✅ updated combined version

import BusBooking from "./pages/BusBooking.jsx";
import BusSeatLayout from "./pages/BusSeatLayout.jsx";
import CarBooking from "./pages/CarBooking.jsx";

import Payment from "./pages/Payment.jsx";
import Receipt from "./pages/Receipt.jsx";
import Account from "./pages/Account.jsx";

import Admin from "./pages/Admin.jsx";
import AdminLogin from "./pages/AdminLogin.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";

import Booking from "./pages/Booking.jsx";

// ✅ Navigation Links
const navigationItems = [
  { name: "Movies", href: "/movies", icon: Film },
  { name: "Concerts", href: "/concerts", icon: Music },
  { name: "Flights", href: "/flights", icon: Plane },
  { name: "Trains", href: "/trains", icon: Train },
  { name: "Buses", href: "/buses", icon: Bus },
  { name: "Cars", href: "/cars", icon: Car },
];

//
// ✅ HEADER COMPONENT
//
function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [userEmail, setUserEmail] = useState(null);

  useEffect(() => {
    const email = localStorage.getItem("userEmail");
    setUserEmail(email);

    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("userEmail");
    localStorage.removeItem("authToken");
    setUserEmail(null);
    toast.success("Logged out successfully");
    navigate("/");
  };

  const isActive = (path) => location.pathname === path;

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white/80 backdrop-blur shadow-md" : "bg-white/60 backdrop-blur"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* ✅ Logo */}
          <Link
            to="/"
            className="flex items-center space-x-2 text-2xl font-bold font-display bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent"
          >
            <Ticket className="h-8 w-8 text-indigo-600" />
            <span>GrabYourTickets</span>
          </Link>

          {/* ✅ Desktop Nav */}
          <nav className="hidden lg:flex items-center space-x-8">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`flex items-center space-x-1 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive(item.href)
                      ? "bg-indigo-100 text-indigo-700"
                      : "text-gray-700 hover:text-indigo-600 hover:bg-indigo-50"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>

          {/* ✅ User Actions */}
          <div className="flex items-center space-x-4">
            {userEmail ? (
              <>
                <div className="hidden sm:flex items-center space-x-2 text-sm text-gray-700">
                  <User className="h-4 w-4" />
                  <span className="truncate max-w-32">{userEmail}</span>
                </div>
                <Link to="/account" className="p-2 rounded hover:bg-gray-100">
                  <Settings className="h-4 w-4" />
                </Link>
                <button
                  onClick={handleLogout}
                  className="bg-red-500 text-white px-3 py-1 rounded-lg text-sm flex items-center space-x-1 hover:bg-red-600"
                >
                  <LogOut className="h-4 w-4" />
                  <span className="hidden sm:inline">Logout</span>
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="px-3 py-1 rounded-lg text-sm text-gray-700 hover:bg-indigo-50 hover:text-indigo-700"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  className="px-3 py-1 rounded-lg bg-indigo-600 text-white text-sm hover:bg-indigo-700"
                >
                  Sign Up
                </Link>
              </>
            )}

            {/* ✅ Mobile Menu Toggle */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden p-2 rounded hover:bg-gray-100"
            >
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* ✅ Mobile Nav */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden border-t border-gray-200 py-4 bg-white/90 backdrop-blur"
            >
              <nav className="flex flex-col space-y-2">
                {navigationItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.name}
                      to={item.href}
                      onClick={() => setIsMenuOpen(false)}
                      className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                        isActive(item.href)
                          ? "bg-indigo-100 text-indigo-700"
                          : "text-gray-700 hover:text-indigo-600 hover:bg-indigo-50"
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{item.name}</span>
                    </Link>
                  );
                })}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
}

//
// ✅ FOOTER COMPONENT
//
function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-200">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-xl font-bold">
              <Ticket className="h-6 w-6 text-indigo-400" />
              <span>GrabYourTickets</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Your one-stop destination for booking movies, concerts, flights,
              trains, buses, and cars — all in one place.
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-white">Quick Links</h3>
            {navigationItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="block text-gray-400 hover:text-white text-sm"
              >
                {item.name}
              </Link>
            ))}
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-white">Support</h3>
            <Link to="/help" className="block text-gray-400 hover:text-white text-sm">
              Help Center
            </Link>
            <Link to="/contact" className="block text-gray-400 hover:text-white text-sm">
              Contact Us
            </Link>
            <Link to="/privacy" className="block text-gray-400 hover:text-white text-sm">
              Privacy Policy
            </Link>
            <Link to="/terms" className="block text-gray-400 hover:text-white text-sm">
              Terms of Service
            </Link>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-white">Contact Info</h3>
            <p>📧 support@grabyourtickets.com</p>
            <p>📞 +91 98765 43210</p>
            <p>📍 Hyderabad, India</p>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} GrabYourTickets — All Rights Reserved
        </div>
      </div>
    </footer>
  );
}

//
// ✅ MAIN APP
//
export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 text-gray-900">
      <Header />

      <main className="pt-16 pb-12">
        <AnimatePresence mode="wait">
          <Routes>
            {/* User routes */}
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />

            {/* Booking categories */}
            <Route path="/movies" element={<MovieBooking />} />
            <Route path="/concerts" element={<ConcertBooking />} />
            <Route path="/flights" element={<FlightBooking />} />
            <Route path="/trains" element={<TrainBooking />} /> {/* ✅ now using combined stylish version */}
            <Route path="/buses" element={<BusBooking />} />
            <Route path="/bus/:id" element={<BusSeatLayout />} />
            <Route path="/cars" element={<CarBooking />} />

            {/* Booking + payment flow */}
            <Route path="/booking" element={<Booking />} />
            <Route path="/payment" element={<Payment />} />
            <Route path="/receipt" element={<Receipt />} />

            {/* User account */}
            <Route path="/account" element={<Account />} />

            {/* Admin section */}
            <Route path="/admin" element={<Admin />} />
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin/dashboard" element={<AdminDashboard />} />
          </Routes>
        </AnimatePresence>
      </main>

      <Footer />
    </div>
  );
}
