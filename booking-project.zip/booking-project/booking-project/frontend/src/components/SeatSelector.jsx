// src/components/SeatSelector.jsx
import React from "react";
import "../styles/booking.css";

/**
 * Props:
 * - rows: array of row ids (e.g. ["A","B","C"])
 * - cols: number of seats per row (e.g. 4)
 * - unavailable: Set<string> or array of seat ids that are already taken (e.g. ["A1","B2"])
 * - selected: array of seat ids currently selected
 * - onToggle(seatId)
 * - layoutFn(optional) -> string label to show for seat
 */
export default function SeatSelector({
  rows = ["A", "B", "C", "D"],
  cols = 4,
  unavailable = [],
  selected = [],
  onToggle,
  layoutFn,
}) {
  const unavailableSet = new Set(unavailable || []);
  return (
    <div className="seat-grid" style={{ display: "grid", gap: 8 }}>
      {rows.map((r) => (
        <div key={r} style={{ display: "flex", gap: 8 }}>
          {Array.from({ length: cols }).map((_, i) => {
            const id = `${r}${i + 1}`;
            const isUnavailable = unavailableSet.has(id);
            const isSelected = selected.includes(id);
            return (
              <button
                key={id}
                type="button"
                onClick={() => !isUnavailable && onToggle(id)}
                disabled={isUnavailable}
                style={{
                  minWidth: 48,
                  minHeight: 40,
                  borderRadius: 8,
                  border: isSelected ? "2px solid #1e3a8a" : "1px solid #e2e8f0",
                  background: isUnavailable
                    ? "#f8fafc"
                    : isSelected
                    ? "#e0f2fe"
                    : "#ffffff",
                  color: isUnavailable ? "#94a3b8" : "#0f172a",
                  cursor: isUnavailable ? "not-allowed" : "pointer",
                  fontWeight: 600,
                }}
              >
                {layoutFn ? layoutFn(r, i + 1) : id}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
}
