import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const slides = [
  {
    id: "train",
    title: "Book Train Tickets with IRCTC",
    subtitle: "Fast, reliable, and easy reservations.",
    img: "/static/images/train1.svg",
    to: "/trains",
    color: "#6366f1"
  },
  {
    id: "bus",
    title: "Book Bus Tickets with RedBus",
    subtitle: "Comfortable bus rides at affordable prices.",
    img: "/static/images/bus1.svg",
    to: "/buses",
    color: "#f59e42"
  },
  {
    id: "flight",
    title: "Book Flights with Airlines",
    subtitle: "Exclusive discounts on domestic and international flights.",
    img: "/static/images/flight1.svg",
    to: "/flights",
    color: "#06b6d4"
  },
  {
    id: "movie",
    title: "Book Movie Tickets with BookMyShow",
    subtitle: "Catch the latest blockbusters instantly.",
    img: "/static/images/movie1.svg",
    to: "/movies",
    color: "#ef4444"
  },
  {
    id: "car",
    title: "Book Car Rides with Ola",
    subtitle: "Ride anywhere with comfort and reliability.",
    img: "/static/images/car1.svg",
    to: "/cars",
    color: "#22c55e"
  },
  {
    id: "concert",
    title: "Book Concert Tickets with BookMyShow",
    subtitle: "Vibe to live performances and unforgettable nights.",
    img: "/static/images/concert1.svg",
    to: "/concerts",
    color: "#a21caf"
  }
];

export default function HomeSlider() {
  const [current, setCurrent] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="home-slider" style={{ position: "relative", width: "100%", maxWidth: "900px", margin: "0 auto", marginBottom: "2.5rem" }}>
      {slides.map((slide, idx) => (
        <div
          key={slide.id}
          className={`slider-slide${idx === current ? " active" : ""}`}
          style={{
            display: idx === current ? "flex" : "none",
            alignItems: "center",
            justifyContent: "center",
            background: slide.color,
            borderRadius: "2rem",
            boxShadow: "0 8px 32px rgba(31,38,135,0.15)",
            color: "#fff",
            minHeight: "320px",
            padding: "2.5rem 2rem"
          }}
        >
          <img src={slide.img} alt={slide.title} style={{ width: "160px", height: "160px", marginRight: "2.5rem", borderRadius: "1.5rem", boxShadow: "0 2px 8px rgba(0,0,0,0.08)" }} />
          <div>
            <h2 style={{ fontSize: "2.2rem", fontWeight: 700, marginBottom: 12 }}>{slide.title}</h2>
            <p style={{ fontSize: "1.15rem", marginBottom: 24 }}>{slide.subtitle}</p>
            <button
              style={{
                background: "rgba(255,255,255,0.15)",
                color: "#fff",
                border: "none",
                borderRadius: "0.75rem",
                padding: "0.85rem 2rem",
                fontSize: "1.1rem",
                fontWeight: 600,
                cursor: "pointer",
                boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
                transition: "transform 0.2s"
              }}
              onClick={() => navigate(slide.to)}
              onMouseOver={e => e.target.style.transform = "scale(1.05)"}
              onMouseOut={e => e.target.style.transform = "scale(1)"}
            >
              Go to {slide.title.split(' ')[1]}
            </button>
          </div>
        </div>
      ))}
      <div className="slider-controls" style={{ position: "absolute", bottom: 18, left: "50%", transform: "translateX(-50%)", display: "flex", gap: "0.5rem" }}>
        {slides.map((_, idx) => (
          <span
            key={idx}
            style={{
              width: "14px",
              height: "14px",
              borderRadius: "50%",
              background: idx === current ? "#fff" : "rgba(255,255,255,0.4)",
              cursor: "pointer",
              border: "2px solid #fff"
            }}
            onClick={() => setCurrent(idx)}
          />
        ))}
      </div>
    </div>
  );
}
