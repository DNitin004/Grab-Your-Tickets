import React, { useEffect, useState } from "react";
import { CSVLink } from "react-csv";

const TABS = [
  "users",
  "bookings",
  "movies",
  "concerts",
  "trains",
  "buses",
  "flights",
  "cars",
];

function AdminDashboard() {
  const [data, setData] = useState({});
  const [activeTab, setActiveTab] = useState("users");
  const [loading, setLoading] = useState(true);
  const adminKey = localStorage.getItem("adminKey");

  useEffect(() => {
    if (!adminKey) {
      window.location.href = "/admin/login";
      return;
    }

    fetch(`http://127.0.0.1:5000/api/admin/all?admin_key=${adminKey}`)
      .then((res) => res.json())
      .then((json) => {
        setData(json);
        setLoading(false);
      })
      .catch(() => setData({ error: "Failed to load data" }));
  }, [adminKey]);

  if (loading) return <div className="text-center mt-20">Loading admin data...</div>;
  if (data.error) return <div className="text-center mt-20 text-red-600">{data.error}</div>;

  const currentData = data[activeTab] || [];

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold text-indigo-700 mb-6">Admin Dashboard</h1>

      {/* Tabs */}
      <div className="flex flex-wrap mb-6 gap-2">
        {TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg font-semibold ${
              activeTab === tab ? "bg-indigo-600 text-white" : "bg-white border"
            }`}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* CSV Export */}
      <div className="mb-4">
        <CSVLink
          data={currentData}
          filename={`${activeTab}.csv`}
          className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          Export {activeTab} to CSV
        </CSVLink>
      </div>

      {/* Data Table */}
      <div className="overflow-x-auto bg-white rounded-xl shadow p-4">
        {currentData.length === 0 ? (
          <p className="text-gray-600">No {activeTab} data found.</p>
        ) : (
          <table className="min-w-full border-collapse">
            <thead>
              <tr>
                {Object.keys(currentData[0]).map((key) => (
                  <th
                    key={key}
                    className="border px-4 py-2 bg-gray-100 text-left text-sm font-semibold"
                  >
                    {key}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
  {currentData.map((row, idx) => (
    <tr key={idx} className="even:bg-gray-50">
      {Object.keys(row).map((key) => {
        if (key === "qr_base64" && row[key]) {
          // show QR code image
          return (
            <td key={key} className="border px-4 py-2 text-sm">
              <img src={row[key]} alt="QR code" className="w-20 h-20 mx-auto" />
            </td>
          );
        }
        return (
          <td key={key} className="border px-4 py-2 text-sm">
            {typeof row[key] === "object" ? JSON.stringify(row[key]) : row[key]}
          </td>
        );
      })}
    </tr>
  ))}
</tbody>

          </table>
        )}
      </div>
    </div>
  );
}

export default AdminDashboard;
