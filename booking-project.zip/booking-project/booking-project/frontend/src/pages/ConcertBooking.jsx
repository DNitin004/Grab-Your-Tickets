// src/pages/ConcertBooking.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/concert.css";

export default function ConcertBooking() {
  const navigate = useNavigate();

  const concerts = [
    {
      id: 1,
      title: "Indie Nights",
      venue: "City Arena",
      date: "2025-12-25",
      time: "7:00 PM",
      price: 500,
      poster: "/static/images/concert1.svg",
    },
    {
      id: 2,
      title: "Rock Carnival",
      venue: "Open Grounds",
      date: "2025-12-31",
      time: "8:00 PM",
      price: 800,
      poster: "/static/images/concert2.svg",
    },
    {
      id: 3,
      title: "EDM Explosion",
      venue: "Sunset Beach Stage",
      date: "2026-01-05",
      time: "6:30 PM",
      price: 1200,
      poster: "/static/images/concert3.svg",
    },
    {
      id: 4,
      title: "Bollywood Beats",
      venue: "Skyline Theatre",
      date: "2026-01-20",
      time: "8:30 PM",
      price: 1000,
      poster: "/static/images/concert4.svg",
    },
  ];

  const zones = [
    { name: "VIP", rows: 2, seatsPerRow: 10, price: 2000 },
    { name: "GOLD", rows: 3, seatsPerRow: 12, price: 1200 },
    { name: "SILVER", rows: 4, seatsPerRow: 14, price: 700 },
  ];

  const [selectedConcert, setSelectedConcert] = useState(null);
  const [seats, setSeats] = useState([]);
  const [selectedSeats, setSelectedSeats] = useState([]);

  // Generate seat layout dynamically when user picks a concert
  const generateSeats = () => {
    let layout = [];
    zones.forEach((zone) => {
      for (let r = 1; r <= zone.rows; r++) {
        for (let s = 1; s <= zone.seatsPerRow; s++) {
          layout.push({
            id: `${zone.name[0]}${r}-${s}`,
            zone: zone.name,
            price: zone.price,
            status: Math.random() > 0.85 ? "booked" : "available",
          });
        }
      }
    });
    return layout;
  };

  const toggleSeat = (seat) => {
    if (seat.status === "booked") return;

    setSeats((prev) =>
      prev.map((s) =>
        s.id === seat.id
          ? { ...s, status: s.status === "selected" ? "available" : "selected" }
          : s
      )
    );

    setSelectedSeats((prev) =>
      prev.includes(seat.id)
        ? prev.filter((x) => x !== seat.id)
        : [...prev, seat.id]
    );
  };

  const handleSelectConcert = (concert) => {
    setSelectedConcert(concert);
    setSeats(generateSeats());
    setSelectedSeats([]);
  };

  const totalAmount = seats
    .filter((s) => selectedSeats.includes(s.id))
    .reduce((sum, s) => sum + s.price, 0);

  const proceedToPayment = () => {
    if (selectedSeats.length === 0)
      return alert("Please select at least one seat.");

    const booking = {
      category: "Concert",
      item_id: selectedConcert.id,
      item: { title: selectedConcert.title },
      seats: selectedSeats,
      time: `${selectedConcert.date} ${selectedConcert.time}`,
      amount: totalAmount,
      email: localStorage.getItem("userEmail") || "guest@bookme.com",
    };

    localStorage.setItem("pendingBooking", JSON.stringify(booking));
    navigate("/payment");
  };

  return (
    <div className="concert-page">
      {!selectedConcert ? (
        <>
          <h1 className="page-title">🎵 Concerts & Music Events</h1>
          <p className="subtitle">
            Choose your favorite concert and grab your seats before they're gone!
          </p>

          <div className="concert-list">
            {concerts.map((concert) => (
              <div className="concert-card" key={concert.id}>
                <img
                  src={concert.poster}
                  alt={concert.title}
                  className="concert-img"
                />
                <div className="concert-details">
                  <h3>{concert.title}</h3>
                  <p>
                    {concert.venue} • {concert.date} • {concert.time}
                  </p>
                  <strong>Starts from ₹{concert.price}</strong>
                  <button
                    className="search-button"
                    onClick={() => handleSelectConcert(concert)}
                  >
                    Select Seats
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          <div className="header-back">
            <button className="back-btn" onClick={() => setSelectedConcert(null)}>
              ← Back
            </button>
            <h2>
              🎤 {selectedConcert.title} — {selectedConcert.venue}
            </h2>
            <p>
              {selectedConcert.date} • {selectedConcert.time}
            </p>
          </div>

          <div className="stage">STAGE</div>

          {zones.map((zone) => (
            <div key={zone.name} className="zone-section">
              <h3 className="zone-title">
                {zone.name} Zone - ₹{zone.price}
              </h3>
              <div className="zone-grid">
                {seats
                  .filter((s) => s.zone === zone.name)
                  .map((seat) => (
                    <div
                      key={seat.id}
                      className={`seat ${seat.status}`}
                      onClick={() => toggleSeat(seat)}
                    >
                      {seat.id}
                    </div>
                  ))}
              </div>
            </div>
          ))}

          <div className="booking-info">
            <p>
              Selected Seats:{" "}
              <strong>{selectedSeats.join(", ") || "None"}</strong>
            </p>
            <p>
              Total Amount: <strong>₹{totalAmount}</strong>
            </p>
            <button className="proceed-btn" onClick={proceedToPayment}>
              Proceed to Payment
            </button>
          </div>
        </>
      )}
    </div>
  );
}
