import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/booking.css";

const bannerSlides = [
  {
    id: 1,
    title: "🎬 Experience the Magic of Movies",
    desc: "Book your movie tickets instantly and enjoy the latest blockbusters!",
    img: "/uploads/images/movie.jpg",
    to: "/movies",
  },
  {
    id: 2,
    title: "✈️ Fly to Your Dream Destination",
    desc: "Book affordable flights with exclusive offers and seat selection.",
    img: "/uploads/images/flight.jpg",
    to: "/flights",
  },
  {
    id: 3,
    title: "🚆🚌 Travel Smart with Bus & Train Tickets",
    desc: "Comfortable, affordable, and quick bookings across India.",
    img: "/uploads/images/bus.jpg",
    to: "/buses",
  },
  {
    id: 4,
    title: "🎤 Concerts, Events & Live Shows",
    desc: "Grab your passes now before they’re sold out!",
    img: "/uploads/images/concert.jpg",
    to: "/concerts",
  },
];

const bookingCategories = [
  {
    id: "train",
    title: "Train Tickets",
    subtitle: "Book with IRCTC",
    img: "/uploads/images/train.jpg",
    to: "/trains",
  },
  {
    id: "bus",
    title: "Bus Tickets",
    subtitle: "Book with RedBus",
    img: "/uploads/images/bus.jpg",
    to: "/buses",
  },
  {
    id: "flight",
    title: "Flight Tickets",
    subtitle: "Book with Airlines",
    img: "/uploads/images/flight.jpg",
    to: "/flights",
  },
  {
    id: "movie",
    title: "Movie Tickets",
    subtitle: "Book with BookMyShow",
    img: "/uploads/images/movie.jpg",
    to: "/movies",
  },
  {
    id: "car",
    title: "Car Booking",
    subtitle: "Book with Ola",
    img: "/uploads/images/car.jpg",
    to: "/cars",
  },
  {
    id: "concert",
    title: "Concert Tickets",
    subtitle: "Book Events & Shows",
    img: "/uploads/images/concert.jpg",
    to: "/concerts",
  },
];

export default function Home() {
  const navigate = useNavigate();
  const [currentBanner, setCurrentBanner] = useState(0);
  const userName = localStorage.getItem("userName");

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % bannerSlides.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };

  return (
    <div className="home-container">

      {/* NAVBAR */}
      <nav className="main-navbar">
        <h2 className="logo" onClick={() => navigate("/")}>
          GrabYourTickets <span>🎟️</span>
        </h2>

        <div className="nav-right">
          <a onClick={() => navigate("/movies")}>Movies</a>
          <a onClick={() => navigate("/flights")}>Flights</a>
          <a onClick={() => navigate("/buses")}>Buses</a>
          <a onClick={() => navigate("/concerts")}>Concerts</a>

          {userName ? (
            <>
              <span className="username-badge">Hello, {userName}</span>
              <button className="btn-outline" onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <button className="btn-filled" onClick={() => navigate("/login")}>
              Login / Signup
            </button>
          )}
        </div>
      </nav>


      {/* HERO SLIDER */}
      <div className="hero-section">
        {bannerSlides.map((slide, index) => (
          <div
            key={slide.id}
            className={`hero-slide ${index === currentBanner ? "active" : ""}`}
            style={{ backgroundImage: `url(${slide.img})` }}
          >
            <div className="overlay"></div>
            <div className="slide-content">
              <h1>{slide.title}</h1>
              <p>{slide.desc}</p>
              <button className="btn-filled" onClick={() => navigate(slide.to)}>Book Now</button>
            </div>
          </div>
        ))}
      </div>


      {/* BOOKING CARDS */}
      <h2 className="section-title">Available Booking Categories</h2>

      <section className="booking-grid">
        {bookingCategories.map((cat) => (
          <div key={cat.id} className="booking-card" onClick={() => navigate(cat.to)}>
            <img src={cat.img} alt={cat.title} />
            <h3>{cat.title}</h3>
            <p>{cat.subtitle}</p>
            <button className="btn-outline">Book Now</button>
          </div>
        ))}
      </section>


      {/* FOOTER */}
      <footer className="footer">
        © {new Date().getFullYear()} GrabYourTickets — All Rights Reserved.
      </footer>
    </div>
  );
}
