import React, {useState} from 'react'

export default function Admin(){
  const [key,setKey]=useState('')
  const [data,setData]=useState(null)
  async function load(){
    const res = await fetch('http://localhost:5000/api/admin/all',{headers: {'X-ADMIN-KEY': key}})
    const j = await res.json()
    if (j.error) { alert('Unauthorized'); return }
    setData(j)
  }
  return (
    <div>
      <h2>Admin panel</h2>
      <div className="card">
        <input className="input" placeholder="Admin key (default: admin123)" value={key} onChange={e=>setKey(e.target.value)} />
        <button className="btn" onClick={load}>Load data</button>
      </div>
      {data && <div className="card"><h3>All bookings and data</h3><pre style={{whiteSpace:'pre-wrap'}}>{JSON.stringify(data, null, 2)}</pre></div>}
    </div>
  )
}
