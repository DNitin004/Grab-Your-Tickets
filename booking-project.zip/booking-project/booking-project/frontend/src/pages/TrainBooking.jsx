// src/pages/TrainBooking.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/booking.css";

export default function TrainBooking() {
  const navigate = useNavigate();

  // ---------- TRAIN LIST ----------
  const trains = [
    {
      id: 1,
      title: "🚄 Rajdhani Express",
      from: "Hyderabad",
      to: "Delhi",
      time: "08:30 AM",
      price: 950,
      type: "AC 2 Tier",
    },
    {
      id: 2,
      title: "🚆 Duronto Express",
      from: "Mumbai",
      to: "Kolkata",
      time: "10:15 AM",
      price: 870,
      type: "AC 3 Tier",
    },
    {
      id: 3,
      title: "🚄 Shatabdi Express",
      from: "Bangalore",
      to: "Chennai",
      time: "07:00 AM",
      price: 650,
      type: "Chair Car",
    },
    {
      id: 4,
      title: "🚆 Garib Rath",
      from: "Vijayawada",
      to: "Visakhapatnam",
      time: "06:45 PM",
      price: 500,
      type: "AC 3 Tier",
    },
    {
      id: 5,
      title: "🚄 Jan Shatabdi",
      from: "Pune",
      to: "Goa",
      time: "09:20 AM",
      price: 480,
      type: "Second Sitting",
    },
  ];

  const [selectedTrain, setSelectedTrain] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);

  // ---------- SEAT CONFIG ----------
  const compartments = ["A", "B", "C"];
  const seatRows = [1, 2, 3];
  const seatNums = [1, 2, 3, 4];

  const toggleSeat = (seatId) => {
    setSelectedSeats((prev) =>
      prev.includes(seatId)
        ? prev.filter((id) => id !== seatId)
        : [...prev, seatId]
    );
  };

  const total = selectedSeats.length * (selectedTrain?.price || 0);

  // ---------- PAYMENT HANDLER ----------
  const handleProceed = () => {
    if (!selectedSeats.length) return alert("Select at least one seat");

    const payload = {
      category: "train",
      item_id: selectedTrain.id,
      item: { title: selectedTrain.title },
      from: selectedTrain.from,
      to: selectedTrain.to,
      time: selectedTrain.time,
      seats: selectedSeats,
      amount: total,
      email: localStorage.getItem("userEmail") || "guest@bookings.com",
    };

    localStorage.setItem("pendingBooking", JSON.stringify(payload));
    navigate("/payment");
  };

  // ---------- UI ----------
  return (
    <div className="layout-container fade-in">
      {!selectedTrain ? (
        <>
          <h2 className="page-title">🚆 Available Trains</h2>
          <div className="bus-list">
            {trains.map((train) => (
              <div key={train.id} className="bus-card glow-card">
                <h3>{train.title}</h3>
                <p>
                  <strong>{train.from}</strong> ➜ <strong>{train.to}</strong>
                </p>
                <p>🕒 Departure: {train.time}</p>
                <p>💺 Type: {train.type}</p>
                <p>💰 Fare: ₹{train.price}</p>

                <button
                  className="proceed-btn"
                  onClick={() => setSelectedTrain(train)}
                >
                  View Seats
                </button>
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          <h2 className="page-title">
            🚄 {selectedTrain.title} — Seat Layout
          </h2>
          <p>
            {selectedTrain.from} ➜ {selectedTrain.to} | Departure:{" "}
            {selectedTrain.time}
          </p>

          <div className="train-layout">
            {compartments.map((comp) => (
              <div key={comp} className="coach">
                <h4>Coach {comp}</h4>
                <div className="seats-grid">
                  {seatRows.map((r) =>
                    seatNums.map((n) => {
                      const seatId = `${comp}${r}${n}`;
                      const selected = selectedSeats.includes(seatId);
                      return (
                        <div
                          key={seatId}
                          className={`seat ${selected ? "selected" : ""}`}
                          onClick={() => toggleSeat(seatId)}
                        >
                          {seatId}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="booking-summary">
            <p>🪑 Selected Seats: {selectedSeats.join(", ") || "None"}</p>
            <p>💰 Total Amount: ₹{total}</p>

            <div className="actions">
              <button
                className="back-btn"
                onClick={() => {
                  setSelectedSeats([]);
                  setSelectedTrain(null);
                }}
              >
                ← Back to Trains
              </button>

              <button
                className="proceed-btn"
                disabled={!selectedSeats.length}
                onClick={handleProceed}
              >
                Proceed to Payment
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
