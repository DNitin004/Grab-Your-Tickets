import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/payment.css";

// 🧩 Mock APIs
async function postQR({ amount, name, purpose }) {
  return new Promise((resolve) =>
    setTimeout(
      () =>
        resolve({
          qr_base64:
            "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=" +
            encodeURIComponent(`Pay ₹${amount} to ${name} for ${purpose}`),
        }),
      1000
    )
  );
}

async function createBooking(payload) {
  return new Promise((resolve) =>
    setTimeout(() => resolve({ ok: true, booking: payload }), 1500)
  );
}

export default function Payment() {
  const navigate = useNavigate();
  const pending = JSON.parse(localStorage.getItem("pendingBooking") || "null");

  const [name, setName] = useState(localStorage.getItem("userName") || "");
  const [loading, setLoading] = useState(false);
  const [qrSrc, setQrSrc] = useState(null);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!pending) setTimeout(() => navigate("/"), 1000);
    else if (!qrSrc) generateQR();
    // eslint-disable-next-line
  }, []);

  async function generateQR() {
    try {
      setLoading(true);
      const res = await postQR({
        amount: pending.amount || pending.fare,
        name: name || pending.email,
        purpose: `${pending.category || "Booking"} Payment`,
      });
      setQrSrc(res.qr_base64);
    } catch {
      alert("❌ Failed to generate QR");
    } finally {
      setLoading(false);
    }
  }

  async function confirmPayment() {
    if (!pending) return;
    setConfirming(true);
    try {
      const payload = {
        ...pending,
        email: pending.email || localStorage.getItem("userEmail"),
      };
      const resp = await createBooking(payload);
      if (resp.ok) {
        localStorage.removeItem("pendingBooking");
        localStorage.setItem(
          "lastBooking",
          JSON.stringify({ ...payload, qr_base64: qrSrc })
        );
        navigate("/receipt");
      } else {
        alert("⚠️ Payment not verified yet.");
      }
    } catch {
      alert("❌ Payment verification failed.");
    }
    setConfirming(false);
  }

  if (!pending) return <div className="redirecting">Redirecting...</div>;

  return (
    <div className="payment-page">
      <div className="payment-card fade-in">
        <h1 className="title">💳 Secure Payment</h1>
        <p className="subtitle">Scan the QR below to complete your booking</p>

        <div className="payment-info">
          <h2>{pending.item?.title || pending.category}</h2>
          {pending.time && <p>⏰ <b>{pending.time}</b></p>}
          {pending.seats && (
            <p>🎟️ Seats: <b>{pending.seats.join(", ")}</b></p>
          )}
          {pending.pickup && pending.drop && (
            <p>🚗 {pending.pickup} → {pending.drop}</p>
          )}
          <h3 className="amount">💰 ₹ {pending.amount || pending.fare}</h3>
        </div>

        <input
          className="payment-input"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter Your Name"
        />

        <button
          className={`primary-btn ${qrSrc ? "disabled" : ""}`}
          onClick={generateQR}
          disabled={loading || qrSrc}
        >
          {loading ? "Generating QR..." : qrSrc ? "QR Ready ✔" : "Generate QR"}
        </button>

        {qrSrc && (
          <div className="qr-box zoom-in">
            <img src={qrSrc} alt="QR Code" className="qr-img" />
            <p className="note">📱 Scan using GPay, Paytm, PhonePe, or UPI app</p>
            <button
              className="confirm-btn"
              onClick={confirmPayment}
              disabled={confirming}
            >
              {confirming ? "Verifying..." : "✅ I Have Paid — Confirm"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
