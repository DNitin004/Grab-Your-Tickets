import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/booking.css";

export default function CarBooking() {
  const navigate = useNavigate();

  const carTypes = [
    { id: "Mini", seats: 4, pricePerKm: 12, img: "/uploads/images/car-mini.png" },
    { id: "Sedan", seats: 4, pricePerKm: 15, img: "/uploads/images/car-sedan.png" },
    { id: "SUV", seats: 6, pricePerKm: 20, img: "/uploads/images/car-suv.png" },
    { id: "Luxury", seats: 4, pricePerKm: 35, img: "/uploads/images/car-luxury.png" },
  ];

  const cities = [
    "Hyderabad",
    "Bengaluru",
    "Chennai",
    "Mumbai",
    "Pune",
    "Delhi",
    "Kolkata",
    "Goa",
  ];

  const [carType, setCarType] = useState(carTypes[0]);
  const [pickup, setPickup] = useState("");
  const [drop, setDrop] = useState("");
  const [distance, setDistance] = useState(0);

  // Approximate distance matrix
  const distanceMap = {
    Hyderabad: { Bengaluru: 570, Chennai: 630, Mumbai: 710, Goa: 660 },
    Bengaluru: { Hyderabad: 570, Chennai: 340, Mumbai: 980, Goa: 560 },
    Chennai: { Hyderabad: 630, Bengaluru: 340, Mumbai: 1230, Goa: 900 },
    Mumbai: { Hyderabad: 710, Bengaluru: 980, Chennai: 1230, Goa: 590 },
    Goa: { Hyderabad: 660, Bengaluru: 560, Chennai: 900, Mumbai: 590 },
  };

  const calculateDistance = (from, to) => {
    if (from && to && from !== to) {
      const dist =
        distanceMap[from]?.[to] ||
        distanceMap[to]?.[from] ||
        Math.floor(Math.random() * 500 + 100);
      setDistance(dist);
    } else {
      setDistance(0);
    }
  };

  const fare = distance ? distance * carType.pricePerKm : 0;

  const handlePayment = () => {
    if (!pickup || !drop || pickup === drop)
      return alert("Please select different pickup and drop locations!");

    const booking = {
      category: "Car Ride",
      pickup,
      drop,
      carType: carType.id,
      distance,
      fare,
      date: new Date().toLocaleString(),
      email: localStorage.getItem("userEmail") || "guest@grab.com",
    };

    localStorage.setItem("pendingBooking", JSON.stringify(booking));
    navigate("/payment");
  };

  return (
    <div className="car-page">
      <div className="car-header">
        <h1>🚗 Book Your Ride</h1>
        <p>Choose route & car type — get instant fare and pay online</p>
      </div>

      <div className="car-content">
        {/* Car Type Cards */}
        <div className="car-type-list">
          {carTypes.map((car) => (
            <div
              key={car.id}
              className={`car-card ${carType.id === car.id ? "active" : ""}`}
              onClick={() => setCarType(car)}
            >
              <img src={car.img} alt={car.id} className="car-img" />
              <div className="car-info">
                <h3>{car.id}</h3>
                <p>{car.seats} Seats</p>
                <span className="price">₹{car.pricePerKm}/km</span>
              </div>
            </div>
          ))}
        </div>

        {/* Ride Form */}
        <div className="ride-form">
          <label>Pickup Location</label>
          <select
            value={pickup}
            onChange={(e) => {
              setPickup(e.target.value);
              calculateDistance(e.target.value, drop);
            }}
          >
            <option value="">Select Pickup City</option>
            {cities.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>

          <label>Drop Location</label>
          <select
            value={drop}
            onChange={(e) => {
              setDrop(e.target.value);
              calculateDistance(pickup, e.target.value);
            }}
          >
            <option value="">Select Drop City</option>
            {cities.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>

          <div className="fare-summary">
            {pickup && drop && pickup !== drop ? (
              <>
                <p>
                  Distance: <strong>{distance} km</strong>
                </p>
                <p>
                  Estimated Fare: <strong>₹{fare.toLocaleString()}</strong>
                </p>
              </>
            ) : (
              <p>Select both cities to see fare estimate</p>
            )}
          </div>

          <button className="proceed-btn" onClick={handlePayment}>
            Proceed to Payment
          </button>
        </div>
      </div>
    </div>
  );
}
