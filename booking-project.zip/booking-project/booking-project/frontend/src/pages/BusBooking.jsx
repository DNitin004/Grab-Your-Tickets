// src/pages/BusBooking.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/bus.css";

export default function BusBooking() {
  const navigate = useNavigate();
  const [buses, setBuses] = useState([]);

  useEffect(() => {
    // Simulated API call
    const demoBuses = [
      {
        id: 1,
        title: "Hyderabad → Bangalore",
        from: "Hyderabad",
        to: "Bangalore",
        departure: "08:00 AM",
        arrival: "03:00 PM",
        type: "AC Sleeper",
        price: 950,
        seats: 30,
        poster: "/static/images/bus1.svg",
      },
      {
        id: 2,
        title: "Chennai → Coimbatore",
        from: "Chennai",
        to: "Coimbatore",
        departure: "09:30 AM",
        arrival: "02:45 PM",
        type: "Non-AC Seater",
        price: 450,
        seats: 36,
        poster: "/static/images/bus2.svg",
      },
      {
        id: 3,
        title: "Mumbai → Pune",
        from: "Mumbai",
        to: "Pune",
        departure: "06:00 AM",
        arrival: "10:00 AM",
        type: "Volvo AC Seater",
        price: 600,
        seats: 40,
        poster: "/static/images/bus3.svg",
      },
      {
        id: 4,
        title: "Delhi → Chandigarh",
        from: "Delhi",
        to: "Chandigarh",
        departure: "07:45 AM",
        arrival: "12:30 PM",
        type: "Luxury AC Sleeper",
        price: 1100,
        seats: 28,
        poster: "/static/images/bus4.svg",
      },
      {
        id: 5,
        title: "Vijayawada → Visakhapatnam",
        from: "Vijayawada",
        to: "Visakhapatnam",
        departure: "10:15 PM",
        arrival: "06:30 AM",
        type: "Non-AC Sleeper",
        price: 700,
        seats: 32,
        poster: "/static/images/bus5.svg",
      },
    ];
    setBuses(demoBuses);
  }, []);

  const handleSeatSelect = (bus) => {
    navigate(`/bus/${bus.id}`, { state: bus });
  };

  return (
    <div className="booking-container">
      <header className="booking-header">
        <h1>🚌 Book Your Bus Tickets</h1>
        <p>Select a bus and view real-time seat layout</p>
      </header>

      <div className="booking-content">
        {buses.map((bus) => (
          <div key={bus.id} className="booking-card">
            <img
              src={bus.poster}
              alt={bus.title}
              style={{
                width: 110,
                height: 75,
                borderRadius: 10,
                objectFit: "cover",
              }}
            />
            <div className="bus-info">
              <h3>{bus.title}</h3>
              <p className="sub">
                {bus.from} → {bus.to} • {bus.departure} – {bus.arrival}
              </p>
              <p className="type">🛏️ {bus.type}</p>
              <p className="price">₹{bus.price}</p>
              <button
                className="search-button"
                onClick={() => handleSeatSelect(bus)}
              >
                Select Seats
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
