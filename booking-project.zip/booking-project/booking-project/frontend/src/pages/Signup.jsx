import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Signup() {
  const nav = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [loading, setLoading] = useState(false);

  async function registerUser(e) {
    e.preventDefault();
    setLoading(true);

    if (pass !== confirmPass) {
      alert("Passwords do not match!");
      setLoading(false);
      return;
    }

    let users = JSON.parse(localStorage.getItem("users") || "[]");
    let exists = users.find((u) => u.email === email);

    if (exists) {
      alert("Email already registered!");
      setLoading(false);
      return;
    }

    users.push({ name, email, password: pass });
    localStorage.setItem("users", JSON.stringify(users));
    alert("Signup Successful!");
    nav("/login");
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Create Account</h1>
        <p className="small-text">Join us and start booking now ✨</p>

        <form onSubmit={registerUser}>
          <input
            type="text"
            className="auth-input"
            placeholder="Full Name"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
          />

          <input
            type="email"
            className="auth-input"
            placeholder="Email Address"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <input
            type="password"
            className="auth-input"
            placeholder="Password"
            required
            value={pass}
            onChange={(e) => setPass(e.target.value)}
          />

          <input
            type="password"
            className="auth-input"
            placeholder="Confirm Password"
            required
            value={confirmPass}
            onChange={(e) => setConfirmPass(e.target.value)}
          />

          <button className="auth-btn" disabled={loading}>
            {loading ? "Creating..." : "Sign Up"}
          </button>
        </form>

        <p className="switch-text">
          Already have an account?{" "}
          <span onClick={() => nav("/login")}>Login</span>
        </p>
      </div>
    </div>
  );
}
