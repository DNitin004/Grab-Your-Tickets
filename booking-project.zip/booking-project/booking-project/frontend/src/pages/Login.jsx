import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/auth.css";
; // <-- Make sure this is imported

export default function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [loading, setLoading] = useState(false);

  async function loginUser(e) {
    e.preventDefault();
    setLoading(true);

    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const user = users.find(u => u.email === email && u.password === pass);

    if (!user) {
      alert("Invalid Email or Password");
      setLoading(false);
      return;
    }

    localStorage.setItem("userEmail", user.email);
    localStorage.setItem("userName", user.name);
    nav("/");
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1 className="auth-title">Welcome Back 👋</h1>
        <p className="small-text">Login to access your bookings</p>

        <form onSubmit={loginUser} className="auth-form">
          <input
            type="email"
            className="auth-input"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="password"
            className="auth-input"
            placeholder="Password"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
            required
          />

          <button className="auth-btn" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        <p className="switch-text">
          Don't have an account?{" "}
          <span onClick={() => nav("/signup")} className="link-highlight">Create Account</span>
        </p>
      </div>
    </div>
  );
}
