import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/movies.css"; // ✅ updated stylish CSS

// ✅ Mock API — replace with backend later
async function getItems(category) {
  if (category === "movies") {
    return [
      {
        id: 1,
        title: "Avatar: The Way of Water",
        genre: "Sci-Fi",
        language: "English",
        price: 180,
        times: ["10:00 AM", "1:00 PM", "4:00 PM", "8:00 PM"],
        poster: "/static/images/Avatar the way of water.jpg",
      },
      {
        id: 2,
        title: "Leo",
        genre: "Action / Tamil",
        language: "Tamil",
        price: 200,
        times: ["11:00 AM", "2:00 PM", "6:00 PM", "9:00 PM"],
        poster: "/static/images/movie2.svg",
      },
      {
        id: 3,
        title: "RRR",
        genre: "Drama / Telugu",
        language: "Telugu",
        price: 220,
        times: ["9:00 AM", "12:30 PM", "5:30 PM", "9:30 PM"],
        poster: "/static/images/movie3.svg",
      },
    ];
  }
  return [];
}

// ✅ Seat Layout Generator
function generateSeats(rows, cols, premiumRows = ["A", "B"]) {
  const seatPrice = 180;
  const premiumSeatPrice = 260;
  const seats = [];

  rows.forEach((r) => {
    const isPremium = premiumRows.includes(r);
    for (let i = 1; i <= cols; i++) {
      seats.push({
        id: `${r}${i}`,
        status: Math.random() > 0.85 ? "booked" : "available",
        price: isPremium ? premiumSeatPrice : seatPrice,
      });
    }
  });
  return seats;
}

export default function MovieBooking() {
  const navigate = useNavigate();

  const [movies, setMovies] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [selectedTime, setSelectedTime] = useState("");
  const [seats, setSeats] = useState(generateSeats(["A", "B", "C", "D", "E", "F"], 12));
  const [selectedSeats, setSelectedSeats] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const data = await getItems("movies");
        setMovies(data);
      } catch (err) {
        console.error("Failed to fetch movies:", err);
      }
    })();
  }, []);

  const toggleSeat = (seat) => {
    if (seat.status === "booked") return;
    setSeats((prev) =>
      prev.map((s) =>
        s.id === seat.id
          ? { ...s, status: s.status === "selected" ? "available" : "selected" }
          : s
      )
    );
    setSelectedSeats((prev) =>
      prev.includes(seat.id)
        ? prev.filter((x) => x !== seat.id)
        : [...prev, seat.id]
    );
  };

  const totalAmount = seats
    .filter((s) => selectedSeats.includes(s.id))
    .reduce((sum, s) => sum + s.price, 0);

  const handleProceed = () => {
    if (!selectedMovie || !selectedTime) return alert("Please select a movie and showtime");
    if (selectedSeats.length === 0) return alert("Please select seats");

    const pendingBooking = {
      category: "Movie",
      item_id: selectedMovie.id,
      item: { title: selectedMovie.title },
      time: selectedTime,
      seats: selectedSeats,
      amount: totalAmount,
      email: localStorage.getItem("userEmail") || "guest@cinema.com",
    };

    localStorage.setItem("pendingBooking", JSON.stringify(pendingBooking));
    navigate("/payment");
  };

  return (
    <div className="movie-page fade-in">
      <div className="booking-header">
        <h1>🎬 Movie Booking</h1>
        <p>Select your favorite movie, showtime, and seats to continue.</p>
      </div>

      <div className="booking-content">
        {/* Left: Movie list */}
        <div className="movie-list">
          {movies.map((m) => (
            <div
              key={m.id}
              className={`booking-card ${selectedMovie?.id === m.id ? "active" : ""}`}
            >
              <img src={m.poster} alt={m.title} className="poster" />
              <div className="movie-info">
                <h3>{m.title}</h3>
                <p className="details">{m.genre} • {m.language}</p>
                <div className="times">
                  {m.times.map((t) => (
                    <button
                      key={t}
                      className={`time-btn ${selectedTime === t ? "active-time" : ""}`}
                      onClick={() => {
                        setSelectedMovie(m);
                        setSelectedTime(t);
                        setSelectedSeats([]);
                      }}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div className="price">₹{m.price}</div>
            </div>
          ))}
        </div>

        {/* Right: Seat layout */}
        <aside className="theatre-section">
          {!selectedMovie ? (
            <div className="placeholder">🎞 Select a movie and showtime to see seats</div>
          ) : (
            <>
              <div className="seat-summary">
                <strong>{selectedMovie.title}</strong>
                <div className="showtime">{selectedTime}</div>
              </div>

              <div className="screen">SCREEN</div>

              <div className="theatre-layout">
                {["A", "B", "C", "D", "E", "F"].map((r) => (
                  <div key={r} className="row">
                    {seats
                      .filter((s) => s.id.startsWith(r))
                      .map((seat) => (
                        <div
                          key={seat.id}
                          className={`seat ${seat.status} ${
                            seat.price === 260 ? "premium" : "normal"
                          }`}
                          onClick={() => toggleSeat(seat)}
                        >
                          {seat.id}
                        </div>
                      ))}
                  </div>
                ))}
              </div>

              <div className="booking-info">
                <p>🎟 Selected: {selectedSeats.join(", ") || "None"}</p>
                <p>💰 Total: ₹{totalAmount}</p>
                <button className="proceed-btn" onClick={handleProceed}>
                  Proceed to Payment
                </button>
              </div>
            </>
          )}
        </aside>
      </div>
    </div>
  );
}
