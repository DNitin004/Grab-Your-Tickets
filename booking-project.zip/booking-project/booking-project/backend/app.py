from flask import Flask, jsonify, request
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
import json, os, time, random, base64, io
import qrcode
from datetime import datetime

# -----------------------
# Initialize Flask App
# -----------------------
app = Flask(__name__, static_folder="static", static_url_path="/static")
CORS(app)

DATA_FILE = os.path.join(os.path.dirname(__file__), "data.json")
ADMIN_KEY = "admin123"

# -----------------------
# Utility Functions
# -----------------------
def load_data():
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# -----------------------
# Routes
# -----------------------
@app.route("/")
def home():
    return {"message": "🎫 Grab Your Tickets API is running!"}, 200

# --------- General Items ---------
@app.route("/api/items/<category>", methods=["GET"])
def get_items(category):
    data = load_data()
    items = data.get(category, [])
    return jsonify(items)

# --------- Auth ---------
@app.route("/api/auth/signup", methods=["POST"])
def signup():
    data = load_data()
    body = request.json
    email = body.get("email")
    if any(u["email"] == email for u in data["users"]):
        return jsonify({"error": "User already exists"}), 400
    user = {
        "email": email,
        "name": body.get("name", ""),
        "password": generate_password_hash(body.get("password", "")),
        "created_at": time.time()
    }
    data["users"].append(user)
    save_data(data)
    return jsonify({"ok": True, "user": {"email": user["email"], "name": user["name"]}})

@app.route("/api/auth/login", methods=["POST"])
def login():
    data = load_data()
    body = request.json
    email, pw = body.get("email"), body.get("password")

    # Admin override
    if email == "admin@grab.com" and pw == "admin123":
        return jsonify({"ok": True, "user": {"email": email, "name": "Admin"}})

    user = next((u for u in data["users"] if u["email"] == email), None)
    if not user or not check_password_hash(user["password"], pw):
        return jsonify({"error": "Invalid credentials"}), 401
    return jsonify({"ok": True, "user": {"email": user["email"], "name": user["name"]}})

# --------- QR Payment ---------
@app.route("/api/qr", methods=["POST"])
def generate_qr():
    """Generate a dynamic QR code for payment"""
    body = request.json
    amount = body.get("amount", 0)
    name = body.get("name", "User")

    data_string = f"Payment for {name} - ₹{amount} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    qr = qrcode.QRCode(box_size=4, border=2)
    qr.add_data(data_string)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")

    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode("ascii")

    return jsonify({"ok": True, "qr_base64": "data:image/png;base64," + b64})

# --------- Booking ---------
@app.route("/api/book", methods=["POST"])
def book():
    data = load_data()
    body = request.json
    booking_id = f"BK{int(time.time())}{random.randint(100,999)}"

    booking = {
        "id": booking_id,
        "email": body.get("email"),
        "category": body.get("category"),
        "item": body.get("item"),
        "time": body.get("time"),
        "seats": body.get("seats", []),
        "class": body.get("class"),
        "amount": body.get("amount"),
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    # Update item availability
    category, item_id = body.get("category"), body.get("item_id")
    if category and item_id:
        for it in data.get(category, []):
            if str(it.get("id")) == str(item_id):
                if "available" in it:
                    it["available"] = max(0, it["available"] - len(booking["seats"]) or 1)
                if "times_available" in it and booking["time"]:
                    t = booking["time"]
                    if t in it["times_available"]:
                        it["times_available"][t] = max(0, it["times_available"][t] - (len(booking["seats"]) or 1))
                break

    data["bookings"].append(booking)
    save_data(data)

    # Generate QR receipt
    qr = qrcode.QRCode(box_size=3, border=2)
    qr.add_data(f"Booking ID: {booking_id}\nPaid ₹{booking['amount']}")
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode("ascii")
    booking["qr_base64"] = "data:image/png;base64," + b64

    return jsonify({"ok": True, "booking": booking})

@app.route("/api/bookings", methods=["GET"])
def get_bookings():
    email = request.args.get("email")
    data = load_data()
    bookings = [b for b in data["bookings"] if b.get("email") == email] if email else data["bookings"]
    return jsonify(bookings)

# --------- Admin ---------
@app.route("/api/admin/login", methods=["POST"])
def admin_login():
    body = request.json
    if body.get("username") == "admin" and body.get("password") == "admin123":
        return jsonify({"ok": True, "admin_key": ADMIN_KEY})
    return jsonify({"error": "Invalid credentials"}), 401

@app.route("/api/admin/all", methods=["GET"])
def admin_all():
    key = request.headers.get("X-ADMIN-KEY") or request.args.get("admin_key")
    if key != ADMIN_KEY:
        return jsonify({"error": "unauthorized"}), 401
    data = load_data()
    return jsonify(data)

# -----------------------
# Data Initialization
# -----------------------
if __name__ == "__main__":
    if not os.path.exists(DATA_FILE):
        sample = {
            "users": [],
            "bookings": [],
            "movies": [
                {"id":1,"title":"Skyline: The Heist","poster":"/static/images/movie1.svg","price":150,
                 "times":["11:00","14:00","18:00","21:00"],"times_available":{"11:00":50,"14:00":50,"18:00":50,"21:00":50}},
                {"id":2,"title":"Moonlight Sonata","poster":"/static/images/movie2.svg","price":130,
                 "times":["11:00","14:00","18:00","21:00"],"times_available":{"11:00":30,"14:00":30,"18:00":30,"21:00":30}},
                {"id":3,"title":"The Last Sunset","poster":"/static/images/movie3.svg","price":120,
                 "times":["11:00","14:00","18:00","21:00"],"times_available":{"11:00":30,"14:00":30,"18:00":30,"21:00":30}}
            ],
            "concerts": [
                {"id":1,"title":"Indie Nights","venue":"City Arena","price":500,"poster":"/static/images/concert1.svg","available":200},
                {"id":2,"title":"Rock Carnival","venue":"Open Grounds","price":800,"poster":"/static/images/concert2.svg","available":150}
            ],
            "trains": [
                {"id":1,"title":"Express 101","from":"Hyderabad","to":"Vijayawada","departure":"08:00","price":350,"emoji":"🚆","available":200},
                {"id":2,"title":"Coastal Queen","from":"Visakhapatnam","to":"Chennai","departure":"13:30","price":450,"emoji":"🚆","available":180}
            ],
            "buses": [
                {"id":1,"title":"RedBus AC Sleeper","from":"Hyderabad","to":"Bengaluru","departure":"22:00","price":999,"emoji":"🚌","available":50},
                {"id":2,"title":"InterCity Volvo","from":"Hyderabad","to":"Pune","departure":"18:00","price":799,"emoji":"🚌","available":40}
            ],
            "flights": [
                {"id":1,"title":"Airline A101","from":"Hyderabad","to":"Mumbai","departure":"06:00","classes":{"economy":2500,"business":7000},"emoji":"✈️","available":120},
                {"id":2,"title":"Airline B202","from":"Hyderabad","to":"Delhi","departure":"12:30","classes":{"economy":3000,"business":8000},"emoji":"✈️","available":100}
            ],
            "cars": [
                {"id":1,"title":"Ola Sedan","from":"Hyderabad","price_per_km":15,"emoji":"🚗","available":20},
                {"id":2,"title":"Ola Mini","from":"Hyderabad","price_per_km":10,"emoji":"🚗","available":30}
            ]
        }
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(sample, f, indent=2, ensure_ascii=False)
        print("✅ Data file created:", DATA_FILE)

    print("🚀 Flask backend running on http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
