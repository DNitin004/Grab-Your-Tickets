const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

const seatsFile = path.join(__dirname, "../data/seats.json");

// Load seats
const loadSeats = () => {
  if (!fs.existsSync(seatsFile)) return {};
  return JSON.parse(fs.readFileSync(seatsFile));
};

// Save seats
const saveSeats = (seats) => fs.writeFileSync(seatsFile, JSON.stringify(seats, null, 2));

// GET available seats for a trip
router.get("/:type/:tripId", (req, res) => {
  const { type, tripId } = req.params;
  const seats = loadSeats();
  res.json(seats[`${type}-${tripId}`] || []);
});

// POST book seats
router.post("/book", (req, res) => {
  const { type, tripId, seats: selectedSeats } = req.body;
  const allSeats = loadSeats();
  const key = `${type}-${tripId}`;
  if (!allSeats[key]) allSeats[key] = [];

  // Check if seats are already booked
  const alreadyBooked = selectedSeats.some(seat => allSeats[key].includes(seat));
  if (alreadyBooked) return res.status(400).json({ message: "Some seats are already booked." });

  allSeats[key] = [...allSeats[key], ...selectedSeats];
  saveSeats(allSeats);

  res.json({ success: true, bookedSeats: selectedSeats });
});

module.exports = router;
