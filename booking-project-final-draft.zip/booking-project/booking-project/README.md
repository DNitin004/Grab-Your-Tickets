# 🎫 GrabYourTickets - Professional Booking Platform

A modern, full-stack booking platform built with React, Tailwind CSS, and Flask. Experience seamless booking for movies, concerts, flights, trains, buses, and more with a professional, responsive design.

![GrabYourTickets](https://img.shields.io/badge/Version-2.0.0-blue)
![React](https://img.shields.io/badge/React-18.2.0-61dafb)
![Flask](https://img.shields.io/badge/Flask-3.0.0-green)
![Tailwind CSS](https://img.shields.io/badge/Tailwind%20CSS-3.3.5-38bdf8)

## ✨ Features

### 🎨 Modern UI/UX
- **Professional Design System**: Consistent colors, typography, and spacing
- **Responsive Layout**: Optimized for all screen sizes (mobile, tablet, desktop)
- **Smooth Animations**: Framer Motion animations for enhanced user experience
- **Glass Morphism**: Modern glass effects and backdrop blur
- **Dark/Light Theme Support**: Adaptive color schemes

### 🔐 Authentication & Security
- **Secure Login/Signup**: Password strength validation and email verification
- **JWT Token Support**: Ready for production authentication
- **Form Validation**: Real-time validation with error handling
- **Password Security**: Bcrypt hashing and strength indicators

### 🎬 Booking Features
- **Multi-Category Booking**: Movies, Concerts, Flights, Trains, Buses, Cars
- **Interactive Seat Selection**: Visual seat maps with real-time availability
- **Smart Search & Filters**: Advanced filtering by location, date, language
- **Price Comparison**: Best deals and pricing transparency
- **QR Code Receipts**: Digital tickets with QR codes

### 🚀 Performance & Reliability
- **React Query**: Efficient data fetching and caching
- **Error Handling**: Comprehensive error boundaries and user feedback
- **Loading States**: Smooth loading indicators throughout the app
- **Toast Notifications**: User-friendly success/error messages
- **Optimized Images**: High-quality images with lazy loading

## 🏗️ Project Structure

```
booking-project/
├── backend/                 # Flask API Server
│   ├── app.py              # Main Flask application
│   ├── requirements.txt    # Python dependencies
│   ├── data.json          # Sample data storage
│   └── static/            # Static assets
├── frontend/               # React Frontend
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── pages/         # Page components
│   │   ├── styles/        # CSS files
│   │   ├── App.jsx        # Main app component
│   │   └── main.jsx       # App entry point
│   ├── package.json       # Node dependencies
│   ├── tailwind.config.js # Tailwind configuration
│   └── vite.config.js     # Vite configuration
└── README.md              # This file
```

## 🚀 Quick Start

### Prerequisites
- **Node.js** (v16 or higher)
- **Python** (v3.8 or higher)
- **npm** or **yarn**

### 1. Clone the Repository
```bash
git clone <repository-url>
cd booking-project
```

### 2. Backend Setup
```bash
cd backend

# Create virtual environment (Windows)
py -m venv .venv
.venv\Scripts\activate

# Install dependencies
py -m pip install -r requirements.txt

# Start the server
py app.py
```
The backend will run at `http://localhost:5000`

### 3. Frontend Setup
```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```
The frontend will run at `http://localhost:5173`

## 🎯 Usage

### Demo Credentials
- **Email**: `admin@grab.com`
- **Password**: `admin123`

### Key Features to Try
1. **Browse Movies**: Filter by city, date, and language
2. **Seat Selection**: Interactive seat map with visual feedback
3. **User Registration**: Password strength validation
4. **Responsive Design**: Test on different screen sizes
5. **Smooth Animations**: Notice the Framer Motion effects

## 🛠️ Technology Stack

### Frontend
- **React 18.2.0** - Modern React with hooks
- **Tailwind CSS 3.3.5** - Utility-first CSS framework
- **Framer Motion 10.16.5** - Animation library
- **React Query 3.39.3** - Data fetching and caching
- **React Hook Form 7.48.2** - Form handling
- **React Hot Toast 2.4.1** - Toast notifications
- **Lucide React 0.294.0** - Icon library
- **Vite 5.0.0** - Build tool and dev server

### Backend
- **Flask 3.0.0** - Python web framework
- **Flask-CORS 4.0.0** - Cross-origin resource sharing
- **Flask-JWT-Extended 4.6.0** - JWT authentication
- **Flask-Limiter 3.5.0** - Rate limiting
- **QRCode 7.4.2** - QR code generation
- **Pillow 12.0.0** - Image processing
- **Bcrypt 4.1.2** - Password hashing
- **Marshmallow 3.20.1** - Data serialization

## 🎨 Design System

### Color Palette
- **Primary**: Blue tones (#3b82f6 to #1e3a8a)
- **Secondary**: Gray tones (#f8fafc to #0f172a)
- **Accent**: Red tones (#ef4444 to #7f1d1d)
- **Success**: Green tones (#22c55e to #14532d)
- **Warning**: Yellow tones (#f59e0b to #78350f)

### Typography
- **Display Font**: Poppins (headings)
- **Body Font**: Inter (body text)
- **Font Weights**: 300-900

### Components
- **Buttons**: Primary, Secondary, Outline, Ghost variants
- **Cards**: Soft shadows with hover effects
- **Forms**: Consistent input styling with validation
- **Navigation**: Responsive header with mobile menu

## 📱 Responsive Design

The application is fully responsive with breakpoints:
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

## 🔧 Development

### Available Scripts
```bash
# Frontend
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint

# Backend
py app.py           # Start Flask server
```

### Environment Variables
Create a `.env` file in the backend directory:
```env
FLASK_ENV=development
SECRET_KEY=your-secret-key
JWT_SECRET_KEY=your-jwt-secret
```

## 🚀 Deployment

### Frontend (Vercel/Netlify)
```bash
cd frontend
npm run build
# Deploy the 'dist' folder
```

### Backend (Heroku/Railway)
```bash
cd backend
# Add Procfile: web: gunicorn app:app
# Deploy with requirements.txt
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Unsplash** for high-quality images
- **Lucide** for beautiful icons
- **Tailwind CSS** for the amazing utility framework
- **Framer Motion** for smooth animations

## 📞 Support

For support, email support@grabYourTickets.com or create an issue in the repository.

---

**Made with ❤️ by the GrabYourTickets Team**

*Book fast. Travel faster.*

## 🔗 Connecting Frontend and Backend

If you're running the frontend dev server (Vite) and the Flask backend locally, set the frontend API base to the backend address. The frontend reads the value from the Vite env var `VITE_API_BASE`.

Steps:

1. Start the backend (from the `backend` folder):

```powershell
# Windows example
py -m venv .venv; .venv\Scripts\activate; py -m pip install -r requirements.txt; py app.py
```

2. In the `frontend` folder, create a `.env` file with:

```
VITE_API_BASE="http://localhost:5000"
```

3. Start the frontend:

```powershell
cd frontend; npm install; npm run dev
```

Notes:
- The Flask backend already enables CORS, so the frontend can call it from Vite's dev server.
- If you prefer the frontend to call the backend on the same origin, serve the built frontend files from the Flask `static` folder and set `VITE_API_BASE` to an empty string or omit it.
