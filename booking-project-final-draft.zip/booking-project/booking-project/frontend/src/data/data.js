// src/data/data.js
export const busRoutes = [
  { id: 1, from: "Hyderabad", to: "Bangalore", operator: "Orange Travels", time: "21:00", price: 650 },
  { id: 2, from: "Delhi", to: "Jaipur", operator: "Volvo Connect", time: "19:30", price: 450 },
  { id: 3, from: "Mumbai", to: "Goa", operator: "RedBus Express", time: "22:15", price: 900 },
  { id: 4, from: "Chennai", to: "Bangalore", operator: "SRS Travels", time: "20:45", price: 500 }
];

export const busTypes = [
  { value: "any", label: "Any Type" },
  { value: "ac", label: "AC" },
  { value: "non-ac", label: "Non AC" },
  { value: "sleeper", label: "Sleeper" },
  { value: "volvo", label: "Volvo" }
];

export const carTypes = [
  { type: "mini", name: "Ola Mini", desc: "Affordable hatchback", pricePerKm: 10, capacity: 4, img: "/static/images/car1.svg" },
  { type: "prime", name: "Ola Prime", desc: "Comfortable sedan", pricePerKm: 15, capacity: 4, img: "/static/images/car2.svg" },
  { type: "suv", name: "Ola SUV", desc: "Spacious SUV", pricePerKm: 20, capacity: 6, img: "/static/images/car3.svg" },
  { type: "luxury", name: "Ola Lux", desc: "Premium luxury", pricePerKm: 25, capacity: 4, img: "/static/images/car4.svg" }
];

export const popularLocations = ["Airport", "Railway Station", "Bus Stand", "City Center", "Shopping Mall"];

export const concerts = [
  { id: 1, title: "Global Music Festival", artists: ["Imagine Dragons", "Ed Sheeran", "Post Malone"], genre: "Pop/Rock", date: "2025-12-25", time: "18:00", venue: "DY Patil Stadium, Mumbai", priceFrom: 2999, img: "/static/images/concert1.svg" },
  { id: 2, title: "Classical Fusion Night", artists: ["AR Rahman", "Shreya Ghoshal"], genre: "Classical/Fusion", date: "2025-12-20", time: "19:30", venue: "Jawaharlal Nehru Stadium, Delhi", priceFrom: 1999, img: "/static/images/concert2.svg" },
  { id: 3, title: "Electronic Music Festival", artists: ["Martin Garrix", "David Guetta"], genre: "EDM", date: "2025-12-31", time: "20:00", venue: "Gachibowli Stadium, Hyderabad", priceFrom: 3499, img: "/static/images/concert3.svg" }
];

export const flightCarriers = [
  { id: "AI", name: "Air India" },
  { id: "6E", name: "IndiGo" },
  { id: "UK", name: "Vistara" },
  { id: "EK", name: "Emirates" }
];

export const popularFlights = [
  { from: "Mumbai", to: "Dubai", airline: "Emirates", time: "08:00", price: 22000 },
  { from: "Delhi", to: "Singapore", airline: "Singapore Airlines", time: "13:30", price: 30000 },
  { from: "Bangalore", to: "London", airline: "British Airways", time: "19:00", price: 65000 },
];

export const trainClasses = [
  { value: "SL", label: "Sleeper Class", priceFactor: 1.0 },
  { value: "3A", label: "3 Tier AC", priceFactor: 2.0 },
  { value: "2A", label: "2 Tier AC", priceFactor: 3.0 },
  { value: "1A", label: "1st Class AC", priceFactor: 5.0 },
  { value: "CC", label: "Chair Car", priceFactor: 1.2 }
];

export const popularTrainRoutes = [
  { from: "Mumbai", to: "Delhi", time: "06:00" },
  { from: "Bangalore", to: "Chennai", time: "21:30" },
  { from: "Kolkata", to: "Delhi", time: "11:00" }
];

// Additional exports for missing imports
export const timeSlots = [
  "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", 
  "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", 
  "18:00", "19:00", "20:00", "21:00", "22:00", "23:00"
];

export const cities = [
  "Mumbai", "Delhi", "Bangalore", "Chennai", "Hyderabad", 
  "Kolkata", "Pune", "Ahmedabad", "Jaipur", "Lucknow"
];

export const genres = [
  "Pop", "Rock", "Classical", "Jazz", "Electronic", "Hip-Hop", 
  "Country", "R&B", "Folk", "Blues", "Reggae", "Metal"
];