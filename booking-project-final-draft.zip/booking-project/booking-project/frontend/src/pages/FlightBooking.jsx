import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/flight.css";

export default function FlightBooking() {
  const navigate = useNavigate();

  const cities = [
    "Delhi (DEL)",
    "Mumbai (BOM)",
    "Bangalore (BLR)",
    "Hyderabad (HYD)",
    "Chennai (MAA)",
    "Kolkata (CCU)",
    "Pune (PNQ)",
    "Goa (GOI)",
    "Ahmedabad (AMD)",
    "Jaipur (JAI)",
  ];

  const flights = [
    { id: 1, title: "IndiGo 6E-520", price: 3200, time: "06:15 AM", img: encodeURI("/uploads/images/Akasa Air QP-114.jpg") },
    { id: 2, title: "Air India AI-407", price: 4500, time: "09:30 AM", img: encodeURI("/uploads/images/Air India AI-407.jpg") },
    { id: 3, title: "Vistara UK-810", price: 3800, time: "01:45 PM", img: encodeURI("/uploads/images/Air India AI-407.jpg") },
    { id: 4, title: "SpiceJet SG-211", price: 2700, time: "05:00 PM", img: encodeURI("/uploads/images/SpiceJet SG-211.jpg") },
    { id: 5, title: "Akasa Air QP-114", price: 3100, time: "08:20 PM", img: encodeURI("/uploads/images/Akasa Air QP-114.jpg") },
  ];

  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [depart, setDepart] = useState("");
  const [passengers, setPassengers] = useState(1);
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [loading, setLoading] = useState(false);

  const seatRows = Array.from({ length: 10 }, (_, i) => i + 1);
  const seatCols = ["A", "B", "C", "D", "E", "F"];

  const toggleSeat = (seat) => {
    setSelectedSeats((prev) =>
      prev.includes(seat) ? prev.filter((s) => s !== seat) : [...prev, seat]
    );
  };

  const totalAmount =
    selectedFlight ? selectedFlight.price * Math.max(selectedSeats.length || passengers, 1) : 0;

  async function handleBooking() {
    if (!from || !to || !depart || !selectedFlight) {
      alert("✈️ Please select all flight details before proceeding!");
      return;
    }

    const bookingPayload = {
      email: localStorage.getItem("userEmail") || "guest@demo.com",
      category: "Flight Booking",
      item: selectedFlight,
      from,
      to,
      date: depart,
      time: selectedFlight.time,
      seats: selectedSeats.length ? selectedSeats : [`AutoSeat-${passengers}`],
      amount: totalAmount,
      passengers,
    };

    try {
      setLoading(true);
      // Optional API call (mocked)
      await new Promise((res) => setTimeout(res, 800));
      localStorage.setItem("pendingBooking", JSON.stringify(bookingPayload));
      navigate("/payment");
    } catch (error) {
      console.error(error);
      alert("⚠️ Something went wrong. Try again later.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flight-page">
      <div className="flight-container">
        <h1 className="page-title fade-in">✈️ Book Your Flight</h1>

        <div style={{ textAlign: "center", marginTop: 8 }}>
          <img
            src={encodeURI("/uploads/images/Air India AI-407.jpg")}
            alt="Flights"
            style={{ width: "92%", maxWidth: 980, borderRadius: 8 }}
          />
        </div>

        {/* Booking Form */}
        <div className="booking-form card fade-in">
          <div className="form-row">
            <div className="form-group">
              <label>From</label>
              <select value={from} onChange={(e) => setFrom(e.target.value)}>
                <option value="">Select City</option>
                {cities.map((city) => (
                  <option key={city}>{city}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>To</label>
              <select value={to} onChange={(e) => setTo(e.target.value)}>
                <option value="">Select City</option>
                {cities.filter((city) => city !== from).map((city) => (
                  <option key={city}>{city}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Departure</label>
              <input type="date" value={depart} onChange={(e) => setDepart(e.target.value)} />
            </div>

            <div className="form-group">
              <label>Passengers</label>
              <input
                type="number"
                min="1"
                max="9"
                value={passengers}
                onChange={(e) => setPassengers(Number(e.target.value))}
              />
            </div>
          </div>
        </div>

        {/* Flights List */}
        <h2 className="section-title fade-in">Available Flights</h2>
        <div className="flight-list fade-in">
          {flights.map((f) => (
            <div
              key={f.id}
              className={`flight-card ${selectedFlight?.id === f.id ? "selected" : ""}`}
              onClick={() => setSelectedFlight(f)}
            >
              <img src={f.img} alt="flight" className="flight-icon" />
              <div>
                <h3>{f.title}</h3>
                <p>{f.time} • ₹{f.price}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Seat Layout */}
        {selectedFlight && (
          <div className="seat-section fade-in">
            <h3>Aircraft Layout — {selectedFlight.title}</h3>
            <div className="seats-grid">
              {seatRows.map((r) => (
                <div key={r} className="seat-row">
                  <span className="row-label">{r}</span>
                  {seatCols.map((c) => {
                    const id = `${r}${c}`;
                    const isSelected = selectedSeats.includes(id);
                    return (
                      <button
                        key={id}
                        className={`seat ${isSelected ? "selected" : ""}`}
                        onClick={() => toggleSeat(id)}
                      >
                        {c}
                      </button>
                    );
                  })}
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="booking-summary">
              <p>🎟 Seats: {selectedSeats.join(", ") || "Auto Assigned"}</p>
              <p>💰 Total Fare: ₹{totalAmount}</p>
              <button
                className="proceed-btn glow"
                onClick={handleBooking}
                disabled={loading}
              >
                {loading ? "Processing..." : "Proceed to Payment"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
