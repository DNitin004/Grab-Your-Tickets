import React, { useState } from "react";
import "../styles/admin.css";

function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [toast, setToast] = useState({ message: "", type: "" });
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setToast({ message: "", type: "" });

    try {
      const res = await fetch("http://127.0.0.1:5000/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (res.ok) {
        if (rememberMe) {
          localStorage.setItem("adminKey", data.admin_key);
        } else {
          sessionStorage.setItem("adminKey", data.admin_key);
        }
        setToast({ message: "Login successful! Redirecting...", type: "success" });
        setTimeout(() => window.location.href = "/admin/dashboard", 1200);
      } else {
        setToast({ message: data.error || "Invalid credentials", type: "error" });
      }
    } catch {
      setToast({ message: "Server error. Please try again.", type: "error" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="admin-login-page">
      <div className="bg-visual" aria-hidden />

      <main className="card-container" role="main">
        <header className="card-header">
          <div className="brand">Booking<strong>Admin</strong></div>
          <p className="subtitle">Sign in to manage bookings, users and content</p>
        </header>

        <form onSubmit={handleLogin} className="login-form" noValidate>
          {toast.message && (
            <div className={`toast ${toast.type === "success" ? "ok" : "err"}`} role="status">
              {toast.message}
            </div>
          )}

          <label className="field">
            <span>Username</span>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin@example.com"
              required
              aria-label="Admin username"
            />
          </label>

          <label className="field">
            <span>Password</span>
            <div className="password-row">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
                aria-label="Password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="show-btn"
                aria-pressed={showPassword}
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </label>

          <div className="form-row">
            <label className="checkbox">
              <input type="checkbox" checked={rememberMe} onChange={() => setRememberMe(!rememberMe)} />
              <span>Remember me</span>
            </label>
            <a className="ghost-link" href="/forgot-password">Forgot?</a>
          </div>

          <button className="submit-btn" type="submit" disabled={loading} aria-busy={loading}>
            {loading ? "Logging in…" : "Sign in"}
          </button>
        </form>

        <footer className="card-foot">
          <small>Access is restricted to authorized administrators only.</small>
        </footer>
      </main>
    </div>
  );
}

export default AdminLogin;
