// src/pages/Receipt.jsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/booking.css";

export default function Receipt() {
  const nav = useNavigate();
  const lastBooking = JSON.parse(localStorage.getItem("lastBooking") || "null");
  const [booking, setBooking] = useState(lastBooking);

  useEffect(() => {
    if (!lastBooking) {
      setTimeout(() => nav("/"), 1000);
    }
  }, []);

  if (!booking) return <div className="card" style={{ padding: 20 }}>Loading receipt...</div>;

  return (
    <div className="booking-container" style={{ maxWidth: 850, margin: "0 auto" }}>
      <div className="booking-header">
        <h1>Booking Receipt</h1>
        <p>Your booking has been confirmed 🎉</p>
      </div>

      <div style={{
        background: "rgba(255,255,255,0.15)",
        backdropFilter: "blur(10px)",
        padding: "28px",
        borderRadius: "18px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: "20px",
        boxShadow: "0 4px 25px rgba(0,0,0,0.15)"
      }}>
        
        {/* Left Ticket Info */}
        <div style={{ flex: 1 }}>
          <h2 style={{ margin: 0 }}>{booking.item?.title || booking.category}</h2>
          <p style={{ opacity: 0.8, marginTop: 6 }}>{booking.time}</p>

          <div style={{ marginTop: 14 }}>
            <strong>Seats:</strong> {booking.seats?.join(", ") || "N/A"}
          </div>

          {booking.class && (
            <div style={{ marginTop: 6 }}>
              <strong>Class:</strong> {booking.class}
            </div>
          )}

          <h2 style={{ marginTop: 18 }}>₹ {booking.amount}</h2>
        </div>

        {/* QR Code */}
        <div style={{
          background: "#fff",
          padding: 14,
          borderRadius: 12,
          display: "flex",
          flexDirection: "column",
          alignItems: "center"
        }}>
          <img
            src={booking.qr_base64}
            alt="QR Code"
            style={{ width: 170, height: 170, borderRadius: 8 }}
          />
          <p style={{ marginTop: 6, fontSize: 13, opacity: 0.7 }}>Scan to verify</p>
        </div>
      </div>

      {/* Buttons */}
      <div style={{ marginTop: 24, display: "flex", justifyContent: "center", gap: 18 }}>
        <button className="search-button" onClick={() => window.print()}>
          Print / Save as PDF
        </button>
        <button className="search-button" onClick={() => nav("/")}>
          Back to Home
        </button>
      </div>
    </div>
  );
}
