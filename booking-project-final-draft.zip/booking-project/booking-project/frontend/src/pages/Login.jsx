import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/auth.css";
import { login as apiLogin } from "../lib/api.js";

export default function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [loading, setLoading] = useState(false);

  async function loginUser(e) {
    e?.preventDefault?.();
    setLoading(true);

    // Try backend auth first
    try {
      const res = await apiLogin({ email, password: pass });
      if (res?.ok) {
        const user = res.user || { email, name: res.user?.name || "User" };
        localStorage.setItem("userEmail", user.email);
        localStorage.setItem("userName", user.name || "User");
        setLoading(false);
        nav("/");
        return;
      }
    } catch (err) {
      // fallback to localStorage lookup
      console.warn("Backend login failed, falling back to local users:", err?.message || err);
    }

    // Fallback: localStorage users (existing behaviour)
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const user = users.find((u) => u.email === email && u.password === pass);

    if (!user) {
      alert("Invalid Email or Password");
      setLoading(false);
      return;
    }

    localStorage.setItem("userEmail", user.email);
    localStorage.setItem("userName", user.name);
    setLoading(false);
    nav("/");
  }

  function useDemo() {
    // demo/admin credentials (backend supports admin override)
    setEmail("admin@grab.com");
    setPass("admin123");
    // auto-submit after a short delay for UX
    setTimeout(() => loginUser(), 250);
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1 className="auth-title">Welcome Back 👋</h1>
        <p className="small-text">Login to access your bookings</p>

        <form onSubmit={loginUser} className="auth-form">
          <input
            type="email"
            className="auth-input"
            placeholder="Email Address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="password"
            className="auth-input"
            placeholder="Password"
            value={pass}
            onChange={(e) => setPass(e.target.value)}
            required
          />

          <button className="auth-btn" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>

        <div className="demo-card">
          <div className="demo-text">Quick demo access</div>
          <div className="creds"><strong>Email:</strong> admin@grab.com <span>•</span> <strong>Pass:</strong> admin123</div>
          <button className="demo-btn" onClick={useDemo}>Use Demo Account</button>
        </div>

        <p className="switch-text">
          Don't have an account? {" "}
          <button type="button" onClick={() => nav("/signup")} className="link-highlight link-btn">Create Account</button>
        </p>
      </div>
    </div>
  );
}
