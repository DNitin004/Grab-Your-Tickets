// src/pages/BusSeatLayout.jsx
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../styles/bus.css";

export default function BusSeatLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const bus = location.state;

  const [selectedSeats, setSelectedSeats] = useState([]);
  const [unavailableSeats, setUnavailableSeats] = useState([]);

  // Generate layout dynamically based on bus type
  const generateLayout = () => {
    if (!bus) return [];

    switch (bus.type) {
      case "AC Sleeper":
      case "Luxury AC Sleeper":
      case "Non-AC Sleeper":
        // Two layers (lower + upper berths)
        return [
          { id: "L1" }, { id: "L2" }, { id: "L3" }, { id: "L4" },
          { id: "L5" }, { id: "L6" }, { id: "U1" }, { id: "U2" },
          { id: "U3" }, { id: "U4" }, { id: "U5" }, { id: "U6" },
        ];
      case "Volvo AC Seater":
      case "Non-AC Seater":
      default:
        // Normal 4-per-row layout
        const rows = 10;
        const cols = ["A", "B", "C", "D"];
        return Array.from({ length: rows * cols.length }, (_, i) => {
          const row = Math.floor(i / cols.length) + 1;
          const col = cols[i % cols.length];
          return { id: `${row}${col}` };
        });
    }
  };

  const [seats, setSeats] = useState(generateLayout);

  // Simulate unavailable seats
  useEffect(() => {
    const randomBooked = ["2A", "3B", "L2", "U3", "5C"];
    setUnavailableSeats(randomBooked);
  }, []);

  const toggleSeat = (id) => {
    if (unavailableSeats.includes(id)) return;
    setSelectedSeats((prev) =>
      prev.includes(id)
        ? prev.filter((s) => s !== id)
        : [...prev, id]
    );
  };

  const total = selectedSeats.length * (bus.price || 450);

  const proceed = () => {
    if (selectedSeats.length === 0)
      return alert("Please select at least one seat!");
    const pending = {
      category: "Bus",
      item_id: bus.id,
      item: { title: bus.title },
      seats: selectedSeats,
      time: bus.departure,
      amount: total,
      email: localStorage.getItem("userEmail") || "guest@grab.com",
    };
    localStorage.setItem("pendingBooking", JSON.stringify(pending));
    navigate("/payment");
  };

  return (
    <div className="seat-page">
      <h2 className="page-title">{bus.title}</h2>
      <p className="route">
        {bus.from} → {bus.to} • {bus.departure} ({bus.type})
      </p>

      <div className="bus-layout">
        <div className="driver">🪑 Driver</div>

        <div
          className={`seat-layout ${
            bus.type.includes("Sleeper") ? "sleeper-layout" : "seater-layout"
          }`}
        >
          {seats.map((seat) => {
            const status = unavailableSeats.includes(seat.id)
              ? "booked"
              : selectedSeats.includes(seat.id)
              ? "selected"
              : "available";
            return (
              <div
                key={seat.id}
                className={`seat ${status}`}
                onClick={() => toggleSeat(seat.id)}
              >
                {seat.id}
              </div>
            );
          })}
        </div>
      </div>

      <div className="booking-info">
        <p>Selected: <strong>{selectedSeats.join(", ") || "None"}</strong></p>
        <p>Total: <strong>₹{total}</strong></p>
        <button className="proceed-btn" onClick={proceed}>
          Proceed to Payment
        </button>
        <button className="back-btn" onClick={() => navigate(-1)}>
          ← Back
        </button>
      </div>
    </div>
  );
}
