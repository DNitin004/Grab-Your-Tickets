import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

export default function Booking() {
  const navigate = useNavigate();
  const { type } = useParams(); // get type from route

  // Default to "movies" if type is undefined
  const bookingType = type || "movies";

  const sampleData = {
    movies: [
      { id: 1, name: "Skyline", time: "11:00, 14:00, 18:00", img: encodeURI("/uploads/images/movie.jpg") },
      { id: 2, name: "Moonlight Sonata", time: "10:00, 13:00, 17:00", img: encodeURI("/uploads/images/Avatar the way of water.jpg") },
    ],
    concerts: [
      { id: 1, name: "Rock Carnival", time: "18:00 - 22:00", img: encodeURI("/uploads/images/Rock Carnival.jpeg") },
      { id: 2, name: "Indie Nights", time: "20:00 - 23:00", img: encodeURI("/uploads/images/Bollywood Beats.jpg") },
    ],
    flights: [
      { id: 1, from: "Hyderabad", to: "Bangalore", time: "08:00", img: encodeURI("/uploads/images/Air India AI-407.jpg") },
      { id: 2, from: "Delhi", to: "Mumbai", time: "13:00", img: encodeURI("/uploads/images/SpiceJet SG-211.jpg") },
    ],
    buses: [
      { id: 1, from: "Hyderabad", to: "Chennai", time: "07:00", img: encodeURI("/uploads/images/bus.jpg") },
      { id: 2, from: "Bangalore", to: "Mysore", time: "12:00", img: encodeURI("/uploads/images/bus1.jpg") },
    ],
    cars: [
      { id: 1, from: "Airport", to: "Hotel", time: "Anytime", img: encodeURI("/uploads/images/car.jpg") },
      { id: 2, from: "Station", to: "Downtown", time: "Anytime", img: encodeURI("/uploads/images/SUV.jpg") },
    ],
  };

  const [booked, setBooked] = useState([]);
  const data = sampleData[bookingType] || [];

  const handleBook = (item) => {
    setBooked([...booked, item]);
    alert(`You booked ${item.name || `${item.from} → ${item.to}`} successfully!`);
  };

  return (
    <div className="card-container" style={{ padding: "50px 20px" }}>
      <h2 style={{ textAlign: "center", marginBottom: 30, color: "#38bdf8" }}>
        {bookingType.charAt(0).toUpperCase() + bookingType.slice(1)} Booking
      </h2>

      {data.length === 0 && <p style={{ textAlign: "center", color: "#cbd5e1" }}>No data available</p>}

      {data.map((item) => (
        <div key={item.id} className="card">
          <img src={item.img} alt={item.name || `${item.from}-${item.to}`} />
          <div className="card-content">
            <h3>{item.name || `${item.from} → ${item.to}`}</h3>
            <p>{item.time}</p>
            <button className="glow-btn" onClick={() => handleBook(item)}>
              Book Now
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
