import React, { useEffect, useState } from "react";
import "../styles/admin-dashboard.css";
import { CSVLink } from "react-csv";

const TABS = [
  "users",
  "bookings",
  "movies",
  "concerts",
  "trains",
  "buses",
  "flights",
  "cars",
];

function AdminDashboard() {
  const [data, setData] = useState({});
  const [activeTab, setActiveTab] = useState("users");
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [page, setPage] = useState(1);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const adminKey = localStorage.getItem("adminKey");

  useEffect(() => {
    if (!adminKey) {
      window.location.href = "/admin/login";
      return;
    }

    fetch(`http://127.0.0.1:5000/api/admin/all?admin_key=${adminKey}`)
      .then((res) => res.json())
      .then((json) => {
        setData(json);
        setLoading(false);
      })
      .catch(() => setData({ error: "Failed to load data" }));
  }, [adminKey]);

  if (loading) return <div className="text-center mt-20">Loading admin data...</div>;
  if (data.error) return <div className="text-center mt-20 text-red-600">{data.error}</div>;

  // derived stats
  const users = data.users || [];
  const bookings = data.bookings || [];
  const totalRevenue = bookings.reduce((s, b) => s + (Number(b.amount) || 0), 0);
  const upcoming = bookings.filter(b => b.time).length;

  const currentData = (data[activeTab] || []).filter((row) => {
    if (!query) return true;
    try {
      return JSON.stringify(row).toLowerCase().includes(query.toLowerCase());
    } catch { return true; }
  });

  // If a user is selected, show only that user's bookings when activeTab is bookings
  const userBookings = selectedUser ? (bookings.filter(b => b.email === selectedUser.email) || []) : [];
  const displayData = activeTab === 'bookings' && selectedUser ? userBookings : currentData;

  // CSV headers per type (professional column names)
  const csvHeaders = (tab) => {
    if (tab === 'bookings') return [
      { label: 'Booking ID', key: 'id' },
      { label: 'Email', key: 'email' },
      { label: 'Category', key: 'category' },
      { label: 'Item Title', key: 'item_title' },
      { label: 'Time', key: 'time' },
      { label: 'Seats', key: 'seats' },
      { label: 'Class', key: 'class' },
      { label: 'Amount', key: 'amount' },
      { label: 'Created At', key: 'created_at' },
    ];
    // default: use object keys
    const sample = (data[tab] && data[tab][0]) || {};
    return Object.keys(sample).map(k => ({ label: k, key: k }));
  };

  const csvDataFor = (tab, rows) => {
    if (tab === 'bookings') {
      return (rows || []).map(r => ({
        id: r.id,
        email: r.email,
        category: r.category,
        // r.item can be null or a primitive; guard before accessing .title
        item_title: (r.item && typeof r.item === 'object') ? (r.item.title || JSON.stringify(r.item)) : (r.item || ''),
        time: r.time,
        seats: Array.isArray(r.seats) ? r.seats.join('; ') : r.seats,
        class: r.class,
        amount: r.amount,
        created_at: r.created_at,
      }));
    }
    return rows;
  };

  // Pagination
  const perPage = 12;
  const totalRows = displayData.length;
  const totalPages = Math.max(1, Math.ceil(totalRows / perPage));
  const paginated = displayData.slice((page - 1) * perPage, page * perPage);

  function downloadBookingCSV(booking) {
    const headers = ['Booking ID','Email','Category','Item Title','Time','Seats','Class','Amount','Created At'];
    const itemTitle = typeof booking.item === 'object' ? (booking.item.title || JSON.stringify(booking.item)) : booking.item;
    const seats = Array.isArray(booking.seats) ? '"' + booking.seats.join('; ') + '"' : booking.seats;
    const values = [booking.id, booking.email, booking.category, '"' + (itemTitle || '') + '"', booking.time, seats, booking.class, booking.amount, '"' + (booking.created_at || '') + '"'];
    const csv = headers.join(',') + '\n' + values.join(',');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `booking_${booking.id}.csv`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-7xl mx-auto p-6">
        <header className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-800">Admin Dashboard</h1>
            <p className="text-sm text-slate-500 mt-1">Overview of platform data and quick management tools</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-xs text-slate-500">Total revenue</div>
              <div className="text-lg font-semibold text-emerald-600">₹{totalRevenue}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-500">Bookings</div>
              <div className="text-lg font-semibold text-indigo-600">{bookings.length}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-500">Users</div>
              <div className="text-lg font-semibold text-slate-700">{users.length}</div>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-12 gap-6">
          {/* Sidebar */}
          <aside className="col-span-3 bg-white rounded-xl p-4 shadow">
            <h3 className="text-sm font-semibold text-slate-600 mb-3">Quick Stats</h3>
            <ul className="space-y-3 mb-4">
              <li className="flex items-center justify-between">
                <div className="text-sm text-slate-600">Total Users</div>
                <div className="font-semibold">{users.length}</div>
              </li>
              <li className="flex items-center justify-between">
                <div className="text-sm text-slate-600">Total Bookings</div>
                <div className="font-semibold">{bookings.length}</div>
              </li>
              <li className="flex items-center justify-between">
                <div className="text-sm text-slate-600">Upcoming</div>
                <div className="font-semibold">{upcoming}</div>
              </li>
              <li className="flex items-center justify-between">
                <div className="text-sm text-slate-600">Revenue</div>
                <div className="font-semibold">₹{totalRevenue}</div>
              </li>
            </ul>

            <h3 className="text-sm font-semibold text-slate-600 mb-2">Users</h3>
            <div className="max-h-64 overflow-auto border rounded-lg p-2">
              {users.length === 0 ? (
                <div className="text-sm text-slate-500">No users found</div>
              ) : (
                <ul className="space-y-2">
                  {users.map((u, i) => (
                    <li key={i}>
                      <button
                        onClick={() => { setSelectedUser(u); setActiveTab('bookings'); }}
                        className={`w-full text-left px-3 py-2 rounded-md ${selectedUser?.email === u.email ? 'bg-indigo-50 border' : 'hover:bg-slate-50'}`}
                      >
                        <div className="text-sm font-medium">{u.name || u.email}</div>
                        <div className="text-xs text-slate-500">{u.email}</div>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {selectedUser && (
              <div className="mt-3">
                <div className="text-xs text-slate-500 mb-2">Selected</div>
                <div className="flex gap-2">
                  <button className="px-3 py-1 bg-indigo-600 text-white rounded" onClick={() => setSelectedUser(null)}>Clear</button>
                  <CSVLink
                    data={csvDataFor('bookings', userBookings)}
                    headers={csvHeaders('bookings')}
                    filename={`bookings_${selectedUser.email}_${new Date().toISOString().slice(0,10)}.csv`}
                    className="px-3 py-1 bg-emerald-600 text-white rounded"
                  >
                    Export user's bookings
                  </CSVLink>
                </div>
              </div>
            )}
          </aside>

          {/* Main */}
          <main className="col-span-9">
              <div className="mb-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 flex-wrap">
                {TABS.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-3 py-1 rounded-full text-sm font-medium ${
                      activeTab === tab ? "bg-indigo-600 text-white" : "bg-white border"
                    }`}
                  >
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <input
                  placeholder={`Search ${activeTab}...`}
                  className="px-3 py-2 rounded-lg border bg-white"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
                <CSVLink
                  data={csvDataFor(activeTab, displayData)}
                  headers={csvHeaders(activeTab)}
                  filename={`${activeTab}_${new Date().toISOString().slice(0,10)}.csv`}
                  className="px-3 py-2 bg-emerald-600 text-white rounded-lg text-sm"
                >
                  Export CSV
                </CSVLink>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow p-4 overflow-auto">
              {currentData.length === 0 ? (
                <p className="text-gray-600">No {activeTab} data found.</p>
              ) : (
                <table className="min-w-full border-collapse text-sm">
                  <thead>
                    <tr>
                      {Object.keys(currentData[0]).map((key) => (
                        <th key={key} className="px-4 py-2 text-left text-xs text-slate-500 font-semibold">
                          {key}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {paginated.map((row, idx) => (
                          <tr key={idx} className={`border-t ${idx % 2 === 0 ? 'bg-slate-50' : ''}`}>
                            {Object.keys(row).map((key) => {
                              if (key === "qr_base64" && row[key]) {
                                return (
                                  <td key={key} className="px-4 py-3">
                                    <img src={row[key]} alt="QR" className="w-16 h-16 rounded-md mx-auto" />
                                  </td>
                                );
                              }
                              return (
                                <td key={key} className="px-4 py-3 align-top">
                                  {typeof row[key] === "object" ? JSON.stringify(row[key]) : row[key]}
                                </td>
                              );
                            })}
                            <td className="px-4 py-3">
                              <div className="flex gap-2">
                                <button className="px-2 py-1 text-sm bg-indigo-50 rounded" onClick={() => setSelectedBooking(row)}>View</button>
                                <button className="px-2 py-1 text-sm bg-emerald-50 rounded" onClick={() => downloadBookingCSV(row)}>Export</button>
                              </div>
                            </td>
                          </tr>
                        ))}
                  </tbody>
                </table>
              )}
            </div>

                {/* Pagination controls */}
                <div className="mt-3 flex items-center justify-between">
                  <div className="text-sm text-slate-500">Showing {(page-1)*perPage+1} - {Math.min(page*perPage, totalRows)} of {totalRows}</div>
                  <div className="flex items-center gap-2">
                    <button className="px-3 py-1 border rounded" disabled={page===1} onClick={() => setPage(p => Math.max(1, p-1))}>Prev</button>
                    <div className="px-3 py-1">{page} / {totalPages}</div>
                    <button className="px-3 py-1 border rounded" disabled={page===totalPages} onClick={() => setPage(p => Math.min(totalPages, p+1))}>Next</button>
                  </div>
                </div>

                {/* Booking modal */}
                {selectedBooking && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
                    <div className="bg-white rounded-lg max-w-xl w-full p-4">
                      <div className="flex justify-between items-center mb-3">
                        <h3 className="text-lg font-semibold">Booking Details</h3>
                        <button onClick={() => setSelectedBooking(null)} className="text-sm">Close</button>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div><strong>ID:</strong> {selectedBooking.id}</div>
                        <div><strong>Email:</strong> {selectedBooking.email}</div>
                        <div><strong>Category:</strong> {selectedBooking.category}</div>
                        <div><strong>Item:</strong> {typeof selectedBooking.item === 'object' ? (selectedBooking.item.title || JSON.stringify(selectedBooking.item)) : selectedBooking.item}</div>
                        <div><strong>Time:</strong> {selectedBooking.time}</div>
                        <div><strong>Seats:</strong> {(Array.isArray(selectedBooking.seats) ? selectedBooking.seats.join(', ') : selectedBooking.seats) || '-'}</div>
                        <div><strong>Amount:</strong> ₹{selectedBooking.amount}</div>
                        <div className="mt-3 flex gap-2">
                          <button className="px-3 py-2 bg-emerald-600 text-white rounded" onClick={() => downloadBookingCSV(selectedBooking)}>Export booking</button>
                          <button className="px-3 py-2 bg-slate-200 rounded" onClick={() => setSelectedBooking(null)}>Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
          </main>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;
