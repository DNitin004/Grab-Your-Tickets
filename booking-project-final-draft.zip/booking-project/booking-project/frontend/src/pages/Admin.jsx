import React, { useState } from "react";

export default function Admin() {
  const [key, setKey] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("http://localhost:5000/api/admin/all", {
        headers: { "X-ADMIN-KEY": key || "admin123" },
      });
      const j = await res.json();
      if (j.error) {
        alert("Unauthorized — check your admin key");
        setData(null);
      } else {
        setData(j);
        // store key for dashboard usage
        if (key) localStorage.setItem("adminKey", key);
        else localStorage.setItem("adminKey", "admin123");
        // redirect to dashboard
        window.location.href = "/admin/dashboard";
      }
    } catch (err) {
      alert("Server error — please check backend is running");
    } finally {
      setLoading(false);
    }
  }

  async function downloadAllBookingsCSV() {
    try {
      const res = await fetch('http://localhost:5000/api/admin/all?admin_key=' + (key || 'admin123'));
      const j = await res.json();
      if (j.error) { alert('Unauthorized'); return; }
      const rows = j.bookings || [];
      const headers = ['Booking ID','Email','Category','Item Title','Time','Seats','Class','Amount','Created At'];
      const csvRows = [headers.join(',')];
      for (const r of rows) {
        const itemTitle = typeof r.item === 'object' ? (r.item.title || JSON.stringify(r.item)) : r.item;
        const seats = Array.isArray(r.seats) ? '"' + r.seats.join('; ') + '"' : r.seats;
        const line = [r.id, r.email, r.category, '"' + (itemTitle || '') + '"', r.time, seats, r.class, r.amount, '"' + (r.created_at || '') + '"'].join(',');
        csvRows.push(line);
      }
      const csv = csvRows.join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `all_bookings_${new Date().toISOString().slice(0,10)}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert('Failed to download CSV — check backend');
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-slate-900 to-slate-800 p-6">
      <div className="max-w-2xl w-full bg-white/5 border border-white/6 rounded-2xl p-8 backdrop-blur-md shadow-xl">
        <header className="mb-4">
          <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
          <p className="text-sm text-slate-300 mt-1">Enter your admin key to load the dashboard. (default: admin123)</p>
        </header>

        <div className="flex gap-3">
          <input
            value={key}
            onChange={(e) => setKey(e.target.value)}
            className="flex-1 rounded-lg p-3 bg-white/6 border border-white/8 text-white placeholder:text-slate-400"
            placeholder="Admin key (leave empty for demo)"
            aria-label="Admin key"
          />
          <button
            className="px-5 py-3 rounded-lg bg-gradient-to-r from-pink-500 to-violet-600 text-white font-semibold shadow-md"
            onClick={load}
            disabled={loading}
          >
            {loading ? "Loading..." : "Open Dashboard"}
          </button>
        </div>

        <div className="mt-6 text-slate-300 text-sm">
          <strong>Demo credentials:</strong> admin / admin123 — this is for local testing only.
        </div>

        <div className="mt-4">
          <button onClick={downloadAllBookingsCSV} className="px-4 py-2 bg-amber-500 text-white rounded-md mr-3">Download all bookings CSV</button>
        </div>

        {data && (
          <div className="mt-6 bg-white/3 p-3 rounded-lg text-slate-100">
            <h3 className="font-semibold">Preview</h3>
            <pre className="text-xs mt-2 max-h-40 overflow-auto whitespace-pre-wrap">{JSON.stringify(data, null, 2)}</pre>
          </div>
        )}
      </div>
    </div>
  );
}
