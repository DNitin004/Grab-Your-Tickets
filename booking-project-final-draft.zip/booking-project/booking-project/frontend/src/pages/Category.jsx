import React, {useEffect, useState} from 'react'
import { useNavigate } from 'react-router-dom'

export default function Category({category, title}){
  const [items,setItems] = useState([])
  const nav = useNavigate()
  useEffect(()=>{ fetch('http://localhost:5000/api/items/'+category).then(r=>r.json()).then(setItems) },[category])
  return (
    <div>
      <h2>{title}</h2>
      <div className="grid">
        {items.map(it=>(
          <div className="card" key={it.id}>
            <div className="poster"><img src={it.poster || '/static/images/movie1.svg'} alt="" style={{maxWidth:'100%'}}/></div>
            <h4>{it.title || it.from + ' → ' + it.to}</h4>
            {it.venue && <div>{it.venue}</div>}
            {it.departure && <div>Departure: {it.departure}</div>}
            <p>Price: ₹{it.price || (it.price_per_km ? it.price_per_km + '/km' : (it.classes ? Object.values(it.classes)[0] : '—'))}</p>
            <button className="btn" onClick={()=>nav('/booking?cat='+category+'&id='+it.id)}>Book</button>
          </div>
        ))}
      </div>
    </div>
  )
}
