import React, {useEffect, useState} from 'react'

export default function Account(){
  const [bookings,setBookings]=useState([])
  useEffect(()=>{
    const email = localStorage.getItem('userEmail')
    const last = JSON.parse(localStorage.getItem('lastBooking') || 'null')
    if (last){
      setBookings(b=>[last,...b])
      localStorage.removeItem('lastBooking')
    }
    if (email){
      fetch('http://localhost:5000/api/bookings?email='+encodeURIComponent(email)).then(r=>r.json()).then(setBookings)
    }
  },[])
  function downloadReceipt(b) {
    const receipt = `Booking Receipt\n-------------------\nCategory: ${b.item.title || b.category}\nDate/Time: ${b.time || '—'}\nSeats: ${b.seats && b.seats.join(', ')}\nAmount: ₹${b.amount}`;
    const blob = new Blob([receipt], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt_${b.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <div>
      <h2>Your Bookings</h2>
      {bookings.length===0 && <div className="card">No bookings yet.</div>}
      <div className="grid">
        {bookings.map(b=>(
          <div className="card ticket" key={b.id}>
            <h4>{b.item.title || b.category}</h4>
            <div>When: {b.time || '—'}</div>
            <div>Seats: {b.seats && b.seats.join(', ')}</div>
            <div>Amount: ₹{b.amount}</div>
            {b.qr_base64 && <img src={b.qr_base64} className="qr" alt="qr" />}
            <button className="btn" style={{marginTop:'1rem'}} onClick={()=>downloadReceipt(b)}>Download Receipt</button>
          </div>
        ))}
      </div>
    </div>
  )
}
