import React, { useState, useEffect } from "react";
import "../style.css";

const banners = [
  {
    id: 1,
    title: "Experience the Magic of Movies 🍿",
    desc: "Book your movie tickets instantly and enjoy the latest blockbusters!",
    img: "/assets/banner-movie.jpg",
  },
  {
    id: 2,
    title: "Fly to Your Dream Destination ✈️",
    desc: "Book affordable flights with exclusive offers and seat selection.",
    img: "/assets/banner-flight.jpg",
  },
  {
    id: 3,
    title: "Travel Smart with Bus & Train Tickets 🚆🚌",
    desc: "Comfortable, affordable, and quick bookings across India.",
    img: "/assets/banner-travel.jpg",
  },
  {
    id: 4,
    title: "Concerts, Events & More 🎤🎭",
    desc: "Grab your passes for live concerts and special shows!",
    img: "/assets/banner-concert.jpg",
  },
];

function BannerSlider() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 4000); // Slide every 4 seconds
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="banner-slider">
      {banners.map((banner, index) => (
        <div
          key={banner.id}
          className={`banner-slide ${
            index === currentIndex ? "active" : ""
          }`}
          style={{ backgroundImage: `url(${banner.img})` }}
        >
          <div className="banner-content">
            <h2>{banner.title}</h2>
            <p>{banner.desc}</p>
            <button className="glow-btn">Book Now</button>
          </div>
        </div>
      ))}
    </div>
  );
}

export default BannerSlider;
