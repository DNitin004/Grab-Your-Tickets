import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";

export default function Header() {
  const navigate = useNavigate();
  const email = localStorage.getItem("userEmail");
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("userEmail");
    localStorage.removeItem("authToken");
    navigate("/login");
  };

  return (
    <header className={`fixed w-full top-0 z-50 transition-all backdrop-blur-md ${scrolled ? "bg-black/80 shadow-lg" : "bg-black/50"}`}>
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center h-16">
        <div className="text-white font-bold text-2xl cursor-pointer">
          <Link to="/">GrabYourTickets</Link>
        </div>

        <nav className="flex items-center gap-6 text-white text-lg flex-wrap">
          <Link to="/movies" className="hover:text-indigo-400 transition">Movies</Link>
          <Link to="/concerts" className="hover:text-indigo-400 transition">Concerts</Link>
          <Link to="/trains" className="hover:text-indigo-400 transition">Trains</Link>
          <Link to="/buses" className="hover:text-indigo-400 transition">Buses</Link>
          <Link to="/flights" className="hover:text-indigo-400 transition">Flights</Link>
          <Link to="/cars" className="hover:text-indigo-400 transition">Cars</Link>
          <Link to="/account" className="hover:text-indigo-400 transition">Account</Link>

          {email ? (
            <>
              <span className="text-gray-300 text-sm">({email})</span>
              <button
                onClick={handleLogout}
                className="px-3 py-1 bg-red-600 hover:bg-red-700 rounded-lg font-semibold transition shadow-lg hover:shadow-xl"
              >
                Sign Out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="px-3 py-1 bg-indigo-500 hover:bg-indigo-600 rounded-lg font-semibold transition shadow-md hover:shadow-lg">Login</Link>
              <Link to="/signup" className="px-3 py-1 bg-green-500 hover:bg-green-600 rounded-lg font-semibold transition shadow-md hover:shadow-lg">Sign Up</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
