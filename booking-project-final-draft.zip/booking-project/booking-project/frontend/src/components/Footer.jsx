export default function Footer() {
  return (
    <footer className="bg-black text-white py-12 px-6 md:px-12 text-center relative overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-2xl md:text-3xl font-bold mb-4">GrabYourTickets</h2>
        <p className="mb-6 text-gray-300">Seamless booking experience for movies, flights, trains, buses, concerts, and more.</p>
        <div className="flex justify-center gap-6 mb-4">
          <a href="/" className="hover:text-indigo-400 transition">Home</a>
          <a href="/movies" className="hover:text-indigo-400 transition">Movies</a>
          <a href="/flights" className="hover:text-indigo-400 transition">Flights</a>
          <a href="/account" className="hover:text-indigo-400 transition">Account</a>
        </div>
        <p className="text-gray-500 text-sm">© {new Date().getFullYear()} GrabYourTickets — All rights reserved.</p>
      </div>

      <div className="absolute -top-20 -left-20 w-72 h-72 bg-indigo-500 rounded-full opacity-20 blur-3xl animate-pulse"></div>
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-pink-500 rounded-full opacity-20 blur-3xl animate-pulse"></div>
    </footer>
  );
}
