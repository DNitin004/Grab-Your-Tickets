import { Link } from "react-router-dom";
import { useState, useEffect } from "react";

export default function Navbar() {
  const [userEmail, setUserEmail] = useState(localStorage.getItem("userEmail") || "");
  const [scrolling, setScrolling] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolling(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("userEmail");
    setUserEmail("");
    window.location.href = "/";
  };

  return (
    <nav className={`fixed w-full z-50 transition-all backdrop-blur-md bg-black/40 px-6 md:px-12 py-4 flex justify-between items-center ${scrolling ? "shadow-lg" : ""}`}>
      <div className="text-white font-bold text-2xl cursor-pointer">
        <Link to="/">GrabYourTickets</Link>
      </div>

      <div className="flex items-center gap-6 text-white font-medium text-lg">
        <Link to="/movies" className="hover:text-indigo-400 transition">Movies</Link>
        <Link to="/concerts" className="hover:text-indigo-400 transition">Concerts</Link>
        <Link to="/trains" className="hover:text-indigo-400 transition">Trains</Link>
        <Link to="/buses" className="hover:text-indigo-400 transition">Buses</Link>
        <Link to="/flights" className="hover:text-indigo-400 transition">Flights</Link>
        <Link to="/cars" className="hover:text-indigo-400 transition">Cars</Link>
        <Link to="/account" className="hover:text-indigo-400 transition">Account</Link>

        {userEmail ? (
          <button onClick={handleLogout} className="px-3 py-1 bg-red-600 hover:bg-red-700 rounded-lg transition">
            Sign Out
          </button>
        ) : (
          <>
            <Link to="/login" className="px-3 py-1 bg-indigo-500 hover:bg-indigo-600 rounded-lg transition">Login</Link>
            <Link to="/signup" className="px-3 py-1 bg-green-500 hover:bg-green-600 rounded-lg transition">Sign Up</Link>
          </>
        )}
      </div>
    </nav>
  );
}
